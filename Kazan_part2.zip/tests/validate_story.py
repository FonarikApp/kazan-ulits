#!/usr/bin/env python3
"""Static data validation for КАЗАНЬ: УЛИЦЫ; does not replace Godot runtime tests."""
import json
from collections import deque
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read_json(relative):
    with (ROOT / relative).open(encoding="utf-8") as handle:
        return json.load(handle)

story = read_json("data/story.json")
characters = read_json("data/characters.json")
quests = read_json("data/quests.json")
world = read_json("data/world_notes.json")
transit = read_json("data/transit_1981.json")
scenes = story.get("scenes", {})
errors = []
valid_stats = {"cash", "health", "energy", "hunger", "reputation"}
valid_relations = {"marat", "senya", "galya", "district"}
quest_ids = {q.get("id") for q in quests.get("quests", [])}
character_ids = [c.get("id") for c in characters.get("characters", [])]

for scene_id, scene in scenes.items():
    if not isinstance(scene.get("lines", []), list):
        errors.append(f"{scene_id}: lines must be an array")
    for line_no, line in enumerate(scene.get("lines", []), 1):
        if not line.get("text", "").strip():
            errors.append(f"{scene_id}: empty dialogue line {line_no}")
    for choice in scene.get("choices", []):
        target = choice.get("next")
        if target and target not in scenes:
            errors.append(f"{scene_id}: missing target {target}")
        if not choice.get("text", "").strip():
            errors.append(f"{scene_id}: empty choice text")
        if "next" in choice and not choice.get("next") and "action" not in choice:
            errors.append(f"{scene_id}: null/empty next target without action")
        if choice.get("action") and choice.get("action") not in {"map", "journal", "main_menu"}:
            errors.append(f"{scene_id}: unsupported action {choice.get('action')}")
        if "action" not in choice and "next" not in choice:
            errors.append(f"{scene_id}: choice has no action or next scene")
        effects = choice.get("effects", {})
        for stat, amount in effects.get("stats", {}).items():
            if stat not in valid_stats or not isinstance(amount, int):
                errors.append(f"{scene_id}: invalid stat effect {stat}={amount!r}")
        for relation, amount in effects.get("relations", {}).items():
            if relation not in valid_relations or not isinstance(amount, int):
                errors.append(f"{scene_id}: invalid relation effect {relation}={amount!r}")
        if not isinstance(effects.get("time", 0), int) or effects.get("time", 0) < 0:
            errors.append(f"{scene_id}: invalid time effect")
        for quest_id in effects.get("quests", {}):
            if quest_id not in quest_ids:
                errors.append(f"{scene_id}: unknown quest ID {quest_id}")
        requirements = choice.get("requires", {})
        for quest_id in requirements.get("quests", {}):
            if quest_id not in quest_ids:
                errors.append(f"{scene_id}: requirement references unknown quest ID {quest_id}")
        if not isinstance(requirements.get("items", []), list):
            errors.append(f"{scene_id}: item requirements must be an array")

if len(character_ids) != len(set(character_ids)):
    errors.append("Duplicate character IDs")
if len(quest_ids) != len(quests.get("quests", [])):
    errors.append("Duplicate quest IDs")
if not scenes:
    errors.append("No scenes defined")
for scene_id, scene in scenes.items():
    background = scene.get("background", "courtyard_winter")
    if not (ROOT / "assets" / "backgrounds" / f"{background}_reference.jpg").exists():
        errors.append(f"{scene_id}: missing background asset {background}_reference.jpg")
# Verify every portrait resource and all speaker-to-portrait bindings.
portrait_ids = {Path(c.get("portrait", "")).stem for c in characters.get("characters", []) if c.get("portrait")}
for character in characters.get("characters", []):
    portrait = character.get("portrait", "")
    if portrait:
        resource = ROOT / portrait.replace("res://", "")
        if not resource.exists():
            errors.append(f"{character.get('id')}: missing portrait {portrait}")
for key in portrait_ids:
    if not (ROOT / "assets" / "characters" / f"{key}.png").exists():
        errors.append(f"Missing character sprite {key}.png")
main_script = (ROOT / "scripts" / "main.gd").read_text(encoding="utf-8")
if "func _update_character_portrait" not in main_script:
    errors.append("Dialogue character portrait renderer is missing")
for speaker in ["Сеня", "Грузчик", "Кондуктор", "Незнакомец", "Незнакомый парень", "Организатор клуба", "Сосед", "Сотрудник", "Сотрудница домоуправления", "Ирина", "Андрей", "Тамара Ивановна", "Старший сержант", "Елена Викторовна", "Пётр Семёнович", "Николай Андреевич", "Борис", "Сашка", "Колька"]:
    if f'"{speaker}"' not in main_script:
        errors.append(f"Missing dialogue portrait binding for speaker: {speaker}")

expected_new_portraits = {"irina", "andrey", "tamara", "sergeant", "doctor", "old_worker", "railway_worker", "driver", "teen_boy", "alexey", "senya"}
if not expected_new_portraits.issubset(portrait_ids):
    errors.append("One or more v4.3 character portraits are not registered in characters.json")
if len(character_ids) < 28:
    errors.append("Expected at least 27 character profiles after cast expansion")


# Canonical protagonist identity and delayed nickname gate.
protagonist = next((c for c in characters.get("characters", []) if c.get("id") == "alexey_kuznetsov"), None)
if not protagonist or protagonist.get("name") != "Алексей Кузнецов" or protagonist.get("age") != 15:
    errors.append("Protagonist must be Алексей Кузнецов, age 15")
if not protagonist or protagonist.get("portrait") != "res://assets/characters/alexey.png":
    errors.append("Protagonist portrait is not registered")
state_script = (ROOT / "scripts" / "game_state.gd").read_text(encoding="utf-8")
if '"hero_nickname_unlocked": false' not in state_script or 'if bool(data.get("hero_nickname_unlocked", false)) and bool(data.get("hero_group_joined", false))' not in state_script:
    errors.append("Nickname must remain hidden until group membership and explicit unlock")
if 'state.set_group_membership(bool(effects.group_joined))' not in main_script or 'state.unlock_hero_nickname("Кузнец")' not in main_script:
    errors.append("Story effects cannot correctly award group membership and nickname")
creation_block = main_script.split("func _show_character_creation() -> void:", 1)[-1].split("func _continue_game()", 1)[0]
if '"Алексей"' not in creation_block or '"Кузнецов"' not in creation_block or 'hero_age = 15' not in creation_block:
    errors.append("Character creation does not enforce canonical protagonist identity")
if not any("Алексею Кузнецову пятнадцать" in line.get("text", "") for line in scenes.get("intro_yard", {}).get("lines", [])):
    errors.append("Opening scene does not establish protagonist age and identity")

if "intro_yard" not in scenes:
    errors.append("Missing opening scene intro_yard")
if not world.get("historical_integrity", {}).get("rule"):
    errors.append("Missing historical integrity rule")
if transit.get("year") != 1981 or not transit.get("source_status"):
    errors.append("Missing 1981 transit provenance")
for route in transit.get("tram_routes", []) + transit.get("trolleybus_routes", []):
    if not route.get("endpoints") or not route.get("fact"):
        errors.append(f"Transit route {route.get('number')} is missing source-backed details")

# Ensure the authored main route reaches the New Year arc.
seen = set()
queue = deque(["intro_yard"] if "intro_yard" in scenes else [])
while queue:
    sid = queue.popleft()
    if sid in seen or sid not in scenes:
        continue
    seen.add(sid)
    for choice in scenes[sid].get("choices", []):
        target = choice.get("next")
        if target and target not in seen:
            queue.append(target)
for required in ["chapter2_start", "chapter3_start", "chapter10_start", "chapter20_start", "chapter30_start", "december31", "ending_summary", "chapter33_start", "chapter42_start", "chapter51_start", "jan22_school_walk", "jan22_classroom", "jan22_evening_yard", "jan23_morning", "chapter55_end"]:
    if required not in seen:
        errors.append(f"Main story route cannot reach {required}")

# New everyday-life arc must remain reachable and must not loop on the old morning stop.
if scenes.get("jan22_route_end", {}).get("choices", [{}])[0].get("next") != "jan22_school_walk":
    errors.append("January 22 route must progress to the school-day arc, not loop")
for required in ["jan22_school_buffet", "jan22_galya_home", "jan22_group_talk", "jan22_day_end", "jan23_library", "jan23_stop", "chapter58_start", "ch58_school_gate", "ch58_yard_meet", "chapter59_start", "ch59_transport", "ch59_library", "chapter60_start", "ch60_meeting", "chapter61_start", "ch61_club", "chapter61_epilogue", "chapter62_start", "ch62_stop_work", "ch62_archive", "ch62_yard", "ch62_reflection", "chapter62_epilogue", "chapter86_start", "ch86_library", "ch86_notes", "ch86_after_trial", "chapter86_epilogue", "chapter87_start", "ch87_school", "ch87_workshop", "ch87_evening", "ch88_peace", "ch88_confront", "ch88_exit", "ch89_peace_work", "ch89_confront_stop", "ch89_exit_school", "ch90_peace", "ch90_confront_repair", "ch90_exit", "ending_peace", "ending_hard", "ending_distance"]:
    if required not in seen:
        errors.append(f"Everyday-life arc is unreachable: {required}")
if world.get("period_end") != "1982-03-23":
    errors.append("World notes period_end must cover the latest authored story date")
if not world.get("sensory_direction", {}).get("sound"):
    errors.append("Missing location-specific sound design guidance")

# v4.7 continuity: the January 26 terminal scene must advance, and the new arc must be reachable.
if scenes.get("chapter57_end", {}).get("choices", [{}])[0].get("next") != "chapter58_start":
    errors.append("January 26 ending must advance to chapter 58")
for required in ["ch58_shop", "ch58_private_talk", "ch58_day_end", "ch59_centre", "ch59_paperwork", "ch59_evening", "ch60_meeting_prep", "ch60_after_meeting", "ch61_questions", "ch61_boundary", "ch61_end", "chapter61_epilogue", "ch62_stop_work", "ch62_archive", "ch62_yard", "ch62_reflection", "chapter62_epilogue", "chapter86_start", "ch86_library", "ch86_notes", "ch86_after_trial", "chapter86_epilogue", "chapter87_start", "ch87_school", "ch87_workshop", "ch87_evening", "ch88_peace", "ch88_confront", "ch88_exit", "ch89_peace_work", "ch89_confront_stop", "ch89_exit_school", "ch90_peace", "ch90_confront_repair", "ch90_exit", "ending_peace", "ending_hard", "ending_distance"]:
    if required not in seen:
        errors.append(f"January 27–31 arc is unreachable: {required}")


# v4.9: Senya replaces the former Vityok character and has an independent story arc.
senya_profile = next((c for c in characters.get("characters", []) if c.get("id") == "senya"), None)
if not senya_profile or senya_profile.get("name") != "Сеня" or senya_profile.get("age") != 15:
    errors.append("Senya must be registered as a distinct 15-year-old character")
if not senya_profile or senya_profile.get("portrait") != "res://assets/characters/senya.png":
    errors.append("Senya must use his own portrait resource")
for required in ["senya_first_talk", "senya_bus_stop", "senya_argument", "senya_morning_stairwell", "senya_school_corridor", "senya_family_errand", "senya_evening_truth", "senya_disagreement_after_call", "senya_late_walk_home"]:
    if required not in seen:
        errors.append(f"Senya story arc is unreachable: {required}")
if not any(c.get("next") == "senya_first_talk" for c in scenes.get("jan22_school_end", {}).get("choices", [])):
    errors.append("Jan 22 school exit has no entry into Senya's story arc")


# v4.11: free-roam interactions, travel time and fatigue loop.
game_state_script = (ROOT / "scripts/game_state.gd").read_text(encoding="utf-8")
map_data_script = (ROOT / "scripts/map_data.gd").read_text(encoding="utf-8")
required_runtime_functions = [
    "_show_location_menu", "_district_travel_minutes", "_action_look_around",
    "_action_rest", "_action_buy_bread", "_action_eat_bread", "_action_study",
    "_action_inspect_stairwell", "_action_clear_ice"
]
for function_name in required_runtime_functions:
    if f"func {function_name}(" not in main_script:
        errors.append(f"Missing location gameplay function: {function_name}")
if '"energy": 100' not in game_state_script or '"fatigue_minutes": 0' not in game_state_script:
    errors.append("GameState must include persistent energy and fatigue remainder")
if 'var accumulated_fatigue :=' not in game_state_script or 'data["energy"]' not in game_state_script:
    errors.append("GameState must accumulate fatigue across short actions")
if '"id":"library"' not in map_data_script:
    errors.append("The center district must include the library interaction point")
if 'state.advance_time(travel_minutes)' not in main_script:
    errors.append("District travel must consume in-game time")
if 'eat_button.disabled = not state.has_item("хлеб")' not in main_script:
    errors.append("Food use must be disabled when the inventory has no bread")


# v4.11: February 3–4 story continuation and new optional objectives.
for required in [
    "chapter65_start", "feb3_school_corridor", "feb3_teacher_talk", "feb3_senya_plan",
    "feb3_library_work", "feb3_after_school", "feb3_aunt_errand", "feb3_marat",
    "feb3_rumor_check", "feb3_evening", "chapter66_start", "feb4_home_request",
    "feb4_school_notice", "feb4_housing_office", "feb4_classroom", "feb4_afternoon",
    "feb4_galya_result", "feb4_walk", "chapter66_epilogue"
]:
    if required not in seen:
        errors.append(f"February 3–4 continuation is unreachable: {required}")
if scenes.get("chapter64_epilogue", {}).get("choices", [])[-1].get("next") != "chapter65_start":
    errors.append("February 2 epilogue must provide a transition into February 3")
for required_quest in ["school_commitment", "neighbor_notice"]:
    if required_quest not in quest_ids:
        errors.append(f"Missing February 3–4 side quest: {required_quest}")
if story.get("version") not in (14, 15, "4.17", "4.22", "4.26", "4.27", "4.28", "4.29", "4.30", "4.39"):
    errors.append("Unexpected story data version")

# v4.17: February 7 chapter continuity and new optional quest.
for required in ["chapter69_start", "ch69_book_clue", "ch69_neighbors", "ch69_house_office", "ch69_senya_identifies", "ch69_search_yard", "ch69_factory_gate", "ch69_note_office", "ch69_tramstop", "ch69_notice", "ch69_factory_workshop", "ch69_owner_found", "ch69_owner_help", "ch69_return_home", "ch69_lunch_talk", "ch69_afternoon_yard", "ch69_afternoon_choice", "ch69_club", "ch69_coal", "ch69_homework", "ch69_club_evening", "ch69_evening", "ch69_last_talk", "chapter69_epilogue"]:
    if required not in seen:
        errors.append(f"February 7 chapter is unreachable: {required}")
if scenes.get("chapter68_epilogue", {}).get("choices", [{}])[0].get("next") != "chapter69_start":
    errors.append("Chapter 68 must connect to February 7")
if "lost_workbook" not in quest_ids:
    errors.append("Missing February 7 side quest: lost_workbook")


# v4.12: one-time contextual free-roam episodes.
roam_events = map_data_script.split("const ROAM_EVENTS :=", 1)[-1] if "const ROAM_EVENTS :=" in map_data_script else ""
if not roam_events:
    errors.append("Missing contextual free-roam event registry")
for function_name in ["_show_roam_event", "_resolve_roam_event"]:
    if f"func {function_name}(" not in main_script:
        errors.append(f"Missing contextual event handler: {function_name}")
for event_id in ["queue_help", "tram_mittens", "pass_at_gate", "market_crate", "tram_route_question", "library_reference", "canteen_tray", "club_notice"]:
    if f'"id": "{event_id}"' not in roam_events:
        errors.append(f"Missing free-roam event: {event_id}")
if 'state.set_flag(flag, true)' not in main_script or 'state.get_flag(flag, false)' not in main_script:
    errors.append("Free-roam episodes must be one-time and persisted in save flags")

# v4.13: dedicated high-resolution backgrounds must exist and be assigned to scenes.
for bg in ["teplokontrol_yard_1981", "tramstop_winter_1981", "entrance_stairwell_1981", "factory_gate_winter_1981"]:
    asset = ROOT / "assets" / "backgrounds" / f"{bg}_reference.jpg"
    if not asset.exists():
        errors.append(f"Missing v4.13 background: {asset.name}")
    elif not any(scene.get("background") == bg for scene in scenes.values()):
        errors.append(f"Background is not assigned to any scene: {bg}")

# Final reporting is intentionally at the end so all regression checks are enforced.

# v4.7 continuity: the January 26 terminal scene must advance, and the new arc must be reachable.
if scenes.get("chapter57_end", {}).get("choices", [{}])[0].get("next") != "chapter58_start":
    errors.append("January 26 ending must advance to chapter 58")
for required in ["ch58_shop", "ch58_private_talk", "ch58_day_end", "ch59_centre", "ch59_paperwork", "ch59_evening", "ch60_meeting_prep", "ch60_after_meeting", "ch61_questions", "ch61_boundary", "ch61_end", "chapter61_epilogue"]:
    if required not in seen:
        errors.append(f"January 27–30 arc is unreachable: {required}")
if any(line.get("speaker") == "Кузнец" for sid in ["chapter58_start", "chapter59_start", "chapter60_start", "chapter61_start"] for line in scenes[sid].get("lines", [])):
    errors.append("Nickname must not be used as Alexey's speaker label before group membership")


# v4.10: February 1–2 continuation and side-objective integration.
for required in [
    "chapter63_start", "feb1_school_gate", "feb1_classroom", "feb1_buffet", "feb1_after_school",
    "feb1_home_errand", "feb1_senya_talk", "feb1_stairwell", "feb1_basement",
    "feb1_repair_plan", "feb1_evening_kitchen", "chapter64_start", "feb2_library",
    "feb2_market_queue", "feb2_senya_choice", "feb2_yard", "feb2_evening",
    "chapter64_epilogue"
]:
    if required not in seen:
        errors.append(f"February continuation is unreachable: {required}")
if scenes.get("chapter62_epilogue", {}).get("choices", [])[-1].get("next") != "chapter63_start":
    errors.append("January epilogue must provide a transition into February")
for required_quest in ["stairwell_draft", "school_notes"]:
    if required_quest not in quest_ids:
        errors.append(f"Missing February side quest: {required_quest}")
quest_titles = {q.get("id"): q.get("title") for q in quests.get("quests", [])}
if not quest_titles.get("stairwell_draft") or not quest_titles.get("school_notes"):
    errors.append("February quest titles are missing from quest definitions")
if '"Дата: %02d.%02d.%04d' not in main_script:
    errors.append("Location visit date must use the current saved year")


# v4.14: February 5 chapter and independent background resources.
for required in ["chapter67_start", "feb5_library", "feb5_yard", "feb5_school", "feb5_stand", "feb5_lunch", "feb5_after_school", "feb5_senya_errand", "feb5_marat_talk", "feb5_worker", "feb5_evening", "feb5_reflection"]:
    if required not in seen:
        errors.append(f"February 5 chapter is unreachable: {required}")
for asset in ["yard_morning", "tram_avenue", "entrance_evening", "industrial_evening"]:
    if not (ROOT / "assets" / "backgrounds" / f"{asset}_reference.jpg").exists():
        errors.append(f"Missing v4.14 background: {asset}")
for quest in ["district_stand_research", "yard_access", "senya_family_errand"]:
    if quest not in quest_ids:
        errors.append(f"Missing v4.14 quest: {quest}")
if scenes.get("chapter66_epilogue", {}).get("choices", [{}, {}, {}])[-1].get("next") != "chapter67_start":
    errors.append("Chapter 66 must connect to chapter 67")


# v4.15: February 6 chapter, new quest and unique environment backgrounds.
for required in ["chapter68_start", "feb6_kitchen_talk", "feb6_kitchen_reason", "feb6_senya_gate", "feb6_senya_help", "feb6_yard", "feb6_market", "feb6_market_result", "feb6_workshop", "feb6_worker_talk", "feb6_stop", "feb6_library", "feb6_archive", "feb6_home", "feb6_evening", "chapter68_epilogue"]:
    if required not in seen:
        errors.append(f"February 6 chapter is unreachable: {required}")
if "market_letter" not in quest_ids:
    errors.append("Missing February 6 optional quest: market_letter")
for bg in ["residential_courtyard_1982", "tramline_snow_1982", "communal_entrance_1982", "factory_exterior_1982", "district_library_1982", "school_corridor_1982", "communal_kitchen_1982", "factory_workshop_1982"]:
    if not (ROOT / "assets" / "backgrounds" / f"{bg}_reference.jpg").exists():
        errors.append(f"Missing v4.15 background: {bg}")

# v4.27: the three March outcomes now continue into a shared follow-up campaign.
for ending, target in [("ending_peace", "ch91_after_peace"), ("ending_hard", "ch91_after_hard"), ("ending_distance", "ch91_after_distance")]:
    if not any(choice.get("next") == target for choice in scenes.get(ending, {}).get("choices", [])):
        errors.append(f"{ending} does not continue into its consequence route")
for required in ["ch91_after_peace", "ch91_after_hard", "ch91_after_distance", "chapter91_start", "ch91_school", "ch91_library", "ch91_yard", "ch91_archive_note", "ch91_photo_check", "ch92_teacher", "ch92_workshop", "ch92_factory_records", "ch92_library_check", "ch92_classroom", "ch93_neighbor", "ch93_home", "ch93_senya", "ch93_marat", "ch93_teacher", "chapter94_start", "ch94_marat", "ch94_library", "ch94_school", "ch94_questions", "ch94_senya", "ch94_walk", "ch94_epilogue"]:
    if required not in seen:
        errors.append(f"March 13–15 continuation is unreachable: {required}")
if "yard_archive_photos" not in quest_ids:
    errors.append("Missing March 13–15 optional quest: yard_archive_photos")
if not any(choice.get("action") == "map" for choice in scenes.get("ch94_epilogue", {}).get("choices", [])):
    errors.append("March 15 epilogue must offer a return to free exploration")

# v4.28: persistent hunger, fatigue and home sleep loop.
if '"hunger": 100' not in game_state_script or '"hunger_minutes": 0' not in game_state_script:
    errors.append("GameState must persist hunger and its time remainder")
if 'var accumulated_hunger :=' not in game_state_script or 'starvation_minutes' not in game_state_script:
    errors.append("Hunger depletion and starvation safeguards are missing")
if 'func _action_sleep()' not in main_script or 'state.advance_time(480)' not in main_script:
    errors.append("Eight-hour home sleep action is missing")
if '"id":"home_apartment"' not in map_data_script:
    errors.append("Kuznetsov family apartment is missing from the district map")
if 'state.change_stat("hunger", 35)' not in main_script:
    errors.append("Bread must restore hunger")

# v4.29: March 16–19 campaign continuation.
for required in ["chapter95_start", "ch95_school", "ch95_garage", "ch95_senya", "chapter96_start", "ch96_workshop", "ch96_kolya", "ch96_backyard", "chapter97_start", "ch97_adult", "ch97_yard", "chapter98_start", "ch98_teacher", "ch98_friends", "ch98_epilogue"]:
    if required not in seen:
        errors.append(f"March 16–19 continuation is unreachable: {required}")
if scenes.get("ch94_epilogue", {}).get("choices", [{}])[0].get("next") != "chapter95_start":
    errors.append("Chapter 94 epilogue must connect to chapter 95")
if "garage_wheel_case" not in quest_ids:
    errors.append("Missing March 16–19 side quest: garage_wheel_case")

# Scene timestamps must never rewind player time after free-roam actions.
if "if target_stamp > current_stamp:" not in main_script:
    errors.append("Scene clock can rewind time after player actions")


# v4.40: campaign finale and nickname presentation regression checks.
for required in ["chapter103_final_decision", "ending_103_peace", "ending_103_group", "ending_103_distance"]:
    if required not in scenes:
        errors.append(f"Missing campaign finale scene: {required}")
if scenes.get("chapter103_final_decision", {}).get("choices", [None, None])[1].get("requires", {}).get("group_joined") is not True:
    errors.append("Group ending must require canonical group membership")
if "displayed_speaker = \"Кузнец\" if bool(state.data.get(\"hero_group_joined\", false)) else \"Лёха\"" not in main_script:
    errors.append("Missing contextual hero nameplate logic")

if errors:
    print("FAIL\\n" + "\\n".join(errors))
    raise SystemExit(1)

lines = sum(len(scene.get("lines", [])) for scene in scenes.values())
choices = sum(len(scene.get("choices", [])) for scene in scenes.values())
print(f"PASS: {len(scenes)} scenes, {lines} dialogue lines, {choices} choices")
print(f"PASS: {len(character_ids)} unique characters, {len(quest_ids)} unique quests")
print(f"PASS: all scenes reachable from intro ({len(seen)} of {len(scenes)} scenes)")
print("PASS: all scene targets, quest references, stat and relationship effects resolve")
print(f"PASS: {len(portrait_ids)} character sprite files and dialogue speaker bindings are present")

if '[/center]\\n\\n' not in main_script:
    errors.append("Disclaimer paragraphs must use real line breaks")
