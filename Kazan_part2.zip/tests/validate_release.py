#!/usr/bin/env python3
import json, sys
from pathlib import Path
from collections import deque
R=Path(__file__).resolve().parents[1]
def j(p): return json.loads((R/p).read_text(encoding='utf-8'))
st=j('data/story.json'); q=j('data/quests.json'); ch=j('data/characters.json'); gangs=j('data/historical_groups.json')
sc=st['scenes']; qids={x['id'] for x in q['quests']}; errs=[]
for sid,s in sc.items():
 for line in s.get('lines',[]):
  if not str(line.get('text','')).strip(): errs.append(f'{sid}: empty line')
 bg=s.get('background')
 if bg and not (R/'assets/backgrounds'/f'{bg}_reference.jpg').exists(): errs.append(f'{sid}: missing background {bg}')
 for c in s.get('choices',[]):
  n=c.get('next')
  if n and n not in sc: errs.append(f'{sid}: missing next {n}')
  for qid in c.get('effects',{}).get('quests',{}):
   if qid not in qids: errs.append(f'{sid}: missing quest {qid}')
seen=set(); dq=deque(['intro_yard'])
while dq:
 x=dq.popleft()
 if x in seen or x not in sc: continue
 seen.add(x)
 for c in sc[x].get('choices',[]):
  if c.get('next'): dq.append(c['next'])
for required in ['chapter81_start','ch81_gate_talk','ch81_senya_talk','chapter82_start','ch82_sashka_talk','chapter83_start','ch83_archive','chapter84_start','ch84_meeting','chapter85_start','ch85_yard_end','chapter85_epilogue']:
 if required not in seen: errs.append(f'unreachable required scene {required}')
for file in ['assets/backgrounds/march_school_corridor_reference.jpg','assets/backgrounds/march_block_courtyard_reference.jpg','assets/branding/logo_ku_blood.png']:
 if not (R/file).is_file(): errs.append(f'missing asset {file}')
if len({x['id'] for x in q['quests']}) != len(q['quests']): errs.append('duplicate quest ids')
if len({x['id'] for x in gangs.get('groups',[])}) != len(gangs.get('groups',[])): errs.append('duplicate historical group ids')
if len(gangs.get('sources',[])) < 3: errs.append('historical group dossier lacks source provenance')
if not any(x.get('id') == 'tyap_lyap' and '1980' in x.get('period','') for x in gangs.get('groups',[])): errs.append('Tyap-Lyap chronology not documented')
if sc.get('chapter85_epilogue',{}).get('choices',[{}])[0].get('next') != 'chapter86_start': errs.append('Chapter 85 does not connect to historical group chapter')
if not (R/'scripts/main.gd').read_text(encoding='utf-8').find('func _show_historical_groups()') >= 0: errs.append('historical groups codex UI missing')
# v4.24: music setting and reproducible Android debug export workflow.
main_source = (R/'scripts/main.gd').read_text(encoding='utf-8')
if 'if not bool(settings.get("music", true))' not in main_source:
 errs.append('Music setting is not enforced by the playback function')
if 'func _continue_game()' not in main_source or '_stop_main_theme()' not in main_source.split('func _continue_game()', 1)[1].split('func ', 1)[0]:
 errs.append('Menu music must stop when continuing a saved game')
for sound_file in [
 'assets/audio/ambience_winter_wind.ogg',
 'assets/audio/ambience_tension_drone.ogg',
 'assets/audio/ui_tick.ogg',
 'assets/audio/paper_swish.ogg',
 'assets/audio/footstep_snow.ogg',
 'assets/audio/door_stairwell.ogg',
 'assets/audio/heartbeat.ogg',
]:
 if not (R/sound_file).is_file() or (R/sound_file).stat().st_size < 1000:
  errs.append(f'Missing or invalid audio asset: {sound_file}')
for audio_hook in ['func _setup_sound_design()', 'func _play_sfx(', 'func _set_scene_ambience(', '_play_sfx("paper_swish")', '_play_sfx("footstep_snow")', 'ambience_player']:
 if audio_hook not in main_source:
  errs.append(f'Missing audio integration hook: {audio_hook}')
if 'Звуковые эффекты"' not in main_source or 'Атмосфера локаций и напряжённые фоновые звуки' not in main_source:
 errs.append('Audio settings controls are missing')
preset = (R/'export_presets.cfg.example').read_text(encoding='utf-8')
workflow = (R/'.github/workflows/android.yml').read_text(encoding='utf-8')
if 'version/code=32' not in preset or 'version/name="4.43.0"' not in preset:
 errs.append('Android export preset version metadata is stale')
if 'godot --headless --path . --export-debug "Android" build/Kazan_Ulitsy-debug.apk' not in workflow:
 errs.append('Android debug APK export step is missing')
if 'actions/upload-artifact@v4' not in workflow:
 errs.append('Android APK artifact upload step is missing')
if "sort -V" not in workflow or "Kazan_Ulitsy_v*.zip" not in workflow:
 errs.append('Android CI must select the newest available Kazan_Ulitsy_v*.zip archive')
if sc.get('chapter86_epilogue',{}).get('choices',[{}])[0].get('next') != 'chapter87_start': errs.append('Chapter 86 epilogue does not connect to March finale')
for ending in ['ending_peace','ending_hard','ending_distance']:
 if ending not in sc or not any(c.get('action') == 'main_menu' for c in sc[ending].get('choices',[])): errs.append(f'Missing terminal ending route: {ending}')

for ending, target in [("ending_peace", "ch91_after_peace"), ("ending_hard", "ch91_after_hard"), ("ending_distance", "ch91_after_distance")]:
 if not any(c.get("next") == target for c in sc.get(ending,{}).get("choices",[])): errs.append(f'{ending}: campaign continuation missing')
for sid in ["chapter91_start","ch91_library","ch92_workshop","ch93_senya","chapter94_start","ch94_epilogue"]:
 if sid not in seen: errs.append(f'unreachable March continuation scene {sid}')
if "yard_archive_photos" not in qids: errs.append('March side quest missing')
if not (R/'assets/audio/dj_groove_titry.ogg').is_file():
 errs.append('Main soundtrack asset is missing')
# Final reporting is intentionally at the end so all regression checks are enforced.

# v4.28 needs and sleep gameplay integration.
state_source = (R/'scripts/game_state.gd').read_text(encoding='utf-8')
if '"hunger": 100' not in state_source or '"starvation_minutes": 0' not in state_source:
 errs.append('Persistent hunger system is missing')
if 'func _action_sleep()' not in main_source or 'state.advance_time(480)' not in main_source:
 errs.append('Home sleep interaction is missing')
if '"id":"home_apartment"' not in (R/'scripts/map_data.gd').read_text(encoding='utf-8'):
 errs.append('Home apartment is not reachable through the map data')

manifest = j('RELEASE_MANIFEST.json')
if manifest.get('release') != '4.43.0' or manifest.get('project_version') != '4.43':
 errs.append('Release manifest version is stale')

for required in ['chapter95_start','ch95_garage','ch95_marat','chapter96_start','ch96_backyard','chapter97_start','ch97_adult','ch97_yard','chapter98_start','ch98_epilogue']:
 if required not in seen: errs.append(f'March continuation scene unreachable: {required}')
if sc.get('ch94_epilogue',{}).get('choices',[{}])[0].get('next') != 'chapter95_start': errs.append('Chapter 94 epilogue does not connect to chapter 95')
if 'garage_wheel_case' not in qids: errs.append('Missing optional quest garage_wheel_case')

# Scene timestamps must never rewind player time after free-roam actions.
if "if target_stamp > current_stamp:" not in main_source:
 errs.append("Scene clock can rewind time after player actions")


# v4.30: free-roam economy, meal consumption, transit navigation and exhaustion.
if 'func _odd_job_for_location(' not in main_source or 'func _resolve_odd_job(' not in main_source:
 errs.append('Daily neighborhood odd-job system is missing')
if 'func _action_buy_meal()' not in main_source or 'func _action_eat_meal()' not in main_source:
 errs.append('Canteen meal purchase/consumption is missing')
if 'func _travel_by_transit(' not in main_source or 'func _district_name(' not in main_source:
 errs.append('Interactive public-transit district travel is missing')
if '"exhaustion_minutes": 0' not in state_source or 'accumulated_exhaustion' not in state_source:
 errs.append('Exhaustion consequence and persistent timer are missing')
if 'exhaustion_minutes' not in (R/'scripts/save_manager.gd').read_text(encoding='utf-8'):
 errs.append('Old save migration for exhaustion timer is missing')


# v4.30: spring thaw campaign continuation and optional neighborhood quests.
for required in ['chapter99_start','ch99_caretaker','ch99_wait','chapter100_start','ch100_work','chapter101_start','ch101_library','ch101_school','chapter102_start','ch102_epilogue']:
 if required not in seen: errs.append(f'March spring-thaw story scene unreachable: {required}')
if sc.get('ch98_epilogue',{}).get('choices',[{}])[0].get('next') != 'chapter99_start':
 errs.append('Chapter 98 epilogue does not connect to spring-thaw continuation')
if not {'spring_basement_water','yard_spring_cleanup'}.issubset(qids):
 errs.append('Spring-thaw side quests are missing')

if 'func _roam_event_flag(' not in main_source or 'roam_event_%04d_%02d_%02d_%s_done' not in main_source:
 errs.append('Roaming events are not replayable on a new in-game day')
if '"canteen": {"title":"Помочь вернуть подносы"' not in main_source:
 errs.append('Canteen daily errand is missing')


# v4.31: one-time opening disclaimer before title screen.
if 'func _show_disclaimer()' not in main_source:
 errs.append('First-launch disclaimer screen is missing')
if 'int(settings.get("disclaimer_version", 0)) < 1' not in main_source or 'settings["disclaimer_version"] = 1' not in main_source:
 errs.append('Disclaimer acknowledgement is not versioned and persisted')
if '_show_disclaimer()' not in main_source.split('func _run_intro_sequence()', 1)[1].split('func ', 1)[0]:
 errs.append('Disclaimer is not shown after the intro splash')
if manifest.get('release') != '4.43.0' or manifest.get('project_version') != '4.43':
 errs.append('v4.31 disclaimer release metadata is stale')

if errs:
 print('FAIL')
 print('\\n'.join(errs))
 sys.exit(1)
print(f'PASS: {len(sc)} scenes; {sum(len(s.get("lines",[])) for s in sc.values())} dialogue lines; {sum(len(s.get("choices",[])) for s in sc.values())} choices')
print(f'PASS: {len(qids)} quests; reachable {len(seen)}/{len(sc)} scenes from intro')
print('PASS: all scene targets, quest references, background assets, and release regression checks resolve')
