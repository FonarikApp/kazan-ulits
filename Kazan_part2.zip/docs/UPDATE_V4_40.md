# КАЗАНЬ: УЛИЦЫ — v4.40

## Изменения
- Сохранена вся существующая игра v4.39.
- Исправлен проектный story-validator: он принимает текущую версию данных 4.39.
- Добавлены регрессионные проверки наличия трёх финалов, блокировки группового финала и контекстного имени героя.
- Android export preset обновлён до version name 4.40.0 / version code 30.
- В v4.40 workflow fallback был заявлен, но фактически оставался привязан к старым именам архивов; исправление и автоматический выбор самой новой версии внесены в v4.41.

## Проверки
- `tests/validate_story.py`: PASS.
- `tests/validate_release.py`: PASS.
- ZIP integrity: PASS.
- Godot headless/runtime и Android export: не выполнены, так как в рабочей среде отсутствуют Godot, Android SDK и export templates.
