extends RefCounted
class_name SaveManager

const SETTINGS_PATH := "user://settings.json"
const MAX_SLOTS := 3

static func _save_path(slot: int) -> String:
	return "user://savegame_%d.json" % clampi(slot, 1, MAX_SLOTS)

static func has_save(slot: int) -> bool:
	if FileAccess.file_exists(_save_path(slot)):
		return true
	return slot == 1 and FileAccess.file_exists("user://savegame.json")

static func save_game(state: GameState, slot: int = 1) -> bool:
	state.data["save_version"] = 4
	var file := FileAccess.open(_save_path(slot), FileAccess.WRITE)
	if file == null:
		push_error("Не удалось открыть файл сохранения: %s" % FileAccess.get_open_error())
		return false
	file.store_string(JSON.stringify(state.data, "\t"))
	return true

static func load_game(state: GameState, slot: int = 1) -> bool:
	var path := _save_path(slot)
	if not FileAccess.file_exists(path):
		if slot == 1 and FileAccess.file_exists("user://savegame.json"):
			path = "user://savegame.json"
		else:
			return false
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return false
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if not parsed is Dictionary:
		return false
	var merged := GameState.DEFAULTS.duplicate(true)
	for key in parsed:
		merged[key] = parsed[key]
	# Nested dictionaries are merged too, so older save versions remain readable.
	# v4.9 migration: the former Vitya character is now Senya.
	var relationships_value: Variant = merged.get("relationships", {})
	var saved_relationships: Dictionary = relationships_value if relationships_value is Dictionary else {}
	if saved_relationships.has("vitya") and not saved_relationships.has("senya"):
		saved_relationships["senya"] = saved_relationships["vitya"]
	saved_relationships.erase("vitya")
	merged["relationships"] = saved_relationships
	var flags_value: Variant = merged.get("flags", {})
	var saved_flags: Dictionary = flags_value if flags_value is Dictionary else {}
	var legacy_flag_keys := []
	for flag_key in saved_flags.keys():
		if str(flag_key).contains("vitya"):
			legacy_flag_keys.append(flag_key)
	for flag_key in legacy_flag_keys:
		var new_flag_key := str(flag_key).replace("vitya", "senya")
		if not saved_flags.has(new_flag_key):
			saved_flags[new_flag_key] = saved_flags[flag_key]
		saved_flags.erase(flag_key)
	merged["flags"] = saved_flags
	var legacy_scene_id := str(merged.get("scene_id", ""))
	if legacy_scene_id.contains("vitya"):
		merged["scene_id"] = legacy_scene_id.replace("vitya", "senya")
	for key in ["relationships", "flags", "quests"]:
		var defaults: Dictionary = GameState.DEFAULTS.get(key, {})
		var saved_value: Variant = merged.get(key, {})
		var saved: Dictionary = saved_value if saved_value is Dictionary else {}
		var nested := defaults.duplicate(true)
		for nested_key in saved:
			nested[nested_key] = saved[nested_key]
		merged[key] = nested
	for key in ["visited", "journal", "inventory", "chapter_history"]:
		if not (merged.get(key, []) is Array):
			merged[key] = []
	merged["save_version"] = 4
	merged["hero_age"] = 15
	merged["health"] = clampi(int(merged.get("health", 100)), 0, 100)
	merged["energy"] = clampi(int(merged.get("energy", 100)), 0, 100)
	merged["hunger"] = clampi(int(merged.get("hunger", 100)), 0, 100)
	merged["fatigue_minutes"] = clampi(int(merged.get("fatigue_minutes", 0)), 0, 44)
	merged["hunger_minutes"] = clampi(int(merged.get("hunger_minutes", 0)), 0, 119)
	merged["starvation_minutes"] = clampi(int(merged.get("starvation_minutes", 0)), 0, 89)
	merged["exhaustion_minutes"] = clampi(int(merged.get("exhaustion_minutes", 0)), 0, 179)
	merged["cash"] = maxi(0, int(merged.get("cash", 0)))
	# Canonical protagonist identity is applied to legacy saves as well.
	if str(merged.get("hero_name", "")).strip_edges().is_empty():
		merged["hero_name"] = "Алексей"
	if str(merged.get("hero_surname", "")).strip_edges().is_empty():
		merged["hero_surname"] = "Кузнецов"
	merged["hero_age"] = 15
	if not bool(merged.get("hero_group_joined", false)):
		merged["hero_nickname_unlocked"] = false
		merged["hero_nickname"] = ""
	state.data = merged
	if path == "user://savegame.json":
		save_game(state, 1)
	return true

static func save_settings(settings: Dictionary) -> bool:
	var file := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(settings, "\t"))
	return true

static func load_settings() -> Dictionary:
	if not FileAccess.file_exists(SETTINGS_PATH):
		return {"text_speed": 1.0, "music": true, "sfx": true, "ambience": true}
	var file := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
	var value: Variant = JSON.parse_string(file.get_as_text()) if file else null
	return value if value is Dictionary else {"text_speed": 1.0, "music": true, "sfx": true, "ambience": true}
