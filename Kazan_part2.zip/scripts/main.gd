extends Control

const STORY_PATH := "res://data/story.json"
const BG_DIR := "res://assets/backgrounds/"

var state := GameState.new()
var story: Dictionary = {}
var current_scene: Dictionary = {}
var line_index := 0
var screen_root: Control
var settings := SaveManager.load_settings()
var current_background: TextureRect
var dialogue_label: RichTextLabel
var speaker_label: Label
var choices_box: VBoxContainer
var status_label: Label
var character_portrait: TextureRect
var character_shadow: TextureRect
var current_location_name := ""
var current_location_description := ""
var current_location_id := ""
var current_location_kind := ""
var music_player: AudioStreamPlayer
var ambience_player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var sfx_streams: Dictionary = {}
const MAIN_THEME_PATH := "res://assets/audio/dj_groove_titry.ogg"
const WINTER_AMBIENCE_PATH := "res://assets/audio/ambience_winter_wind.ogg"
const TENSION_AMBIENCE_PATH := "res://assets/audio/ambience_tension_drone.ogg"

func _ready() -> void:
	_setup_music()
	_setup_sound_design()
	_load_story()
	_run_intro_sequence()

func _make_fade_overlay(alpha: float) -> ColorRect:
	var overlay := ColorRect.new()
	overlay.color = Color(0, 0, 0, alpha)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	screen_root.add_child(overlay)
	return overlay

func _fade_to(overlay: ColorRect, target_alpha: float, duration: float) -> void:
	var tween := create_tween()
	tween.tween_property(overlay, "color:a", target_alpha, duration)
	await tween.finished
	if target_alpha <= 0.001:
		overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _run_intro_sequence() -> void:
	if ambience_player != null:
		ambience_player.stop()
	_clear_screen()
	var black := ColorRect.new()
	black.color = Color.BLACK
	black.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen_root.add_child(black)
	var logo := TextureRect.new()
	logo.texture = load("res://assets/branding/logo_ku_blood.png") as Texture2D
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.size = Vector2(320, 320)
	logo.position = Vector2(480, 200)
	logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen_root.add_child(logo)
	var intro_fade := _make_fade_overlay(1.0)
	await _fade_to(intro_fade, 0.0, 1.25)
	await get_tree().create_timer(2.0).timeout
	await _fade_to(intro_fade, 1.0, 1.25)
	if int(settings.get("disclaimer_version", 0)) < 1:
		_show_disclaimer()
		var disclaimer_fade := _make_fade_overlay(1.0)
		await _fade_to(disclaimer_fade, 0.0, 1.0)
	else:
		_show_title()
		var title_fade := _make_fade_overlay(1.0)
		await _fade_to(title_fade, 0.0, 1.1)

func _setup_music() -> void:
	music_player = AudioStreamPlayer.new()
	music_player.name = "MainThemePlayer"
	music_player.bus = "Master"
	var track := load(MAIN_THEME_PATH) as AudioStreamOggVorbis
	if track == null:
		push_error("Не удалось загрузить главный саундтрек: " + MAIN_THEME_PATH)
		return
	track.loop = true
	music_player.stream = track
	add_child(music_player)

func _play_main_theme(restart: bool = false) -> void:
	if music_player == null or music_player.stream == null:
		return
	if not bool(settings.get("music", true)):
		music_player.stop()
		return
	if restart:
		music_player.stop()
	if not music_player.playing:
		music_player.play()

func _stop_main_theme() -> void:
	if music_player != null:
		music_player.stop()


func _setup_sound_design() -> void:
	ambience_player = AudioStreamPlayer.new()
	ambience_player.name = "WorldAmbiencePlayer"
	ambience_player.volume_db = -17.0
	add_child(ambience_player)
	sfx_player = AudioStreamPlayer.new()
	sfx_player.name = "SFXPlayer"
	sfx_player.volume_db = -5.0
	add_child(sfx_player)
	for key in ["ui_tick", "paper_swish", "footstep_snow", "door_stairwell", "heartbeat"]:
		var path: String = "res://assets/audio/%s.ogg" % key
		if ResourceLoader.exists(path):
			sfx_streams[key] = load(path)

func _play_sfx(key: String) -> void:
	if not bool(settings.get("sfx", true)) or sfx_player == null:
		return
	var stream: AudioStream = sfx_streams.get(key)
	if stream == null:
		return
	sfx_player.stream = stream
	sfx_player.play()

func _set_scene_ambience(scene_data: Dictionary) -> void:
	if ambience_player == null:
		return
	if not bool(settings.get("ambience", true)):
		ambience_player.stop()
		return
	var mood := str(scene_data.get("mood", "" )).to_lower()
	var source_text := JSON.stringify(scene_data).to_lower()
	var tense_words := ["опас", "угроз", "страх", "погон", "драка", "милиц", "удар", "засад", "конфликт", "напряж"]
	var tense := mood == "tension"
	if mood.is_empty():
		for word in tense_words:
			if source_text.contains(word):
				tense = true
				break
	var ambience_path := TENSION_AMBIENCE_PATH if tense else WINTER_AMBIENCE_PATH
	var desired := load(ambience_path) as AudioStreamOggVorbis
	if desired == null:
		return
	desired.loop = true
	if ambience_player.stream != desired:
		ambience_player.stop()
		ambience_player.stream = desired
		ambience_player.play()

func _load_story() -> void:
	if not FileAccess.file_exists(STORY_PATH):
		push_error("Не найден файл сюжета")
		return
	var f := FileAccess.open(STORY_PATH, FileAccess.READ)
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	if parsed is Dictionary:
		story = parsed
	else:
		push_error("Ошибка разбора story.json")

func _clear_screen() -> void:
	for child in get_children():
		if child != music_player and child != ambience_player and child != sfx_player:
			child.queue_free()
	screen_root = Control.new()
	screen_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(screen_root)
	var base := ColorRect.new()
	base.color = Color("#111014")
	base.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen_root.add_child(base)
	var top_edge := ColorRect.new()
	top_edge.color = Color("#8f3039")
	top_edge.position = Vector2(0, 0)
	top_edge.size = Vector2(1280, 3)
	top_edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen_root.add_child(top_edge)

func _panel(parent: Control, rect: Rect2, color: Color, radius: int = 12) -> Panel:
	var p := Panel.new()
	p.position = rect.position
	p.size = rect.size
	p.custom_minimum_size = rect.size
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.bg_color.a = 0.94
	style.corner_radius_top_left = 3
	style.corner_radius_top_right = 3
	style.corner_radius_bottom_left = 3
	style.corner_radius_bottom_right = 3
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	style.border_color = Color("#4b3438")
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 14
	style.content_margin_bottom = 14
	p.add_theme_stylebox_override("panel", style)
	parent.add_child(p)
	var accent := ColorRect.new()
	accent.color = Color("#a83a43")
	accent.position = Vector2(0, 0)
	accent.size = Vector2(4, rect.size.y)
	accent.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(accent)
	return p

func _label(parent: Control, text: String, pos: Vector2, size: Vector2, font_size: int, color: Color = Color("#eee9df")) -> Label:
	var l := Label.new()
	l.text = text
	l.position = pos
	l.size = size
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(l)
	return l

func _dialogue_choice_button(parent: Control, text: String, callback: Callable) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(340, 52)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size", 17)
	button.add_theme_color_override("font_color", Color("#e7dfdc"))
	button.add_theme_color_override("font_hover_color", Color("#ffffff"))
	button.add_theme_color_override("font_pressed_color", Color("#ffffff"))
	var normal := StyleBoxTexture.new()
	normal.texture = load("res://assets/ui/choice.png")
	normal.texture_margin_left = 76
	normal.texture_margin_top = 28
	normal.texture_margin_right = 76
	normal.texture_margin_bottom = 28
	var hover := StyleBoxTexture.new()
	hover.texture = load("res://assets/ui/choice_hover.png")
	hover.texture_margin_left = 76
	hover.texture_margin_top = 28
	hover.texture_margin_right = 76
	hover.texture_margin_bottom = 28
	var pressed := hover.duplicate()
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("focus", normal)
	button.add_theme_stylebox_override("disabled", normal)
	button.pressed.connect(_play_sfx.bind("ui_tick"))
	button.pressed.connect(callback)
	parent.add_child(button)
	return button

func _button(parent: Control, text: String, callback: Callable, width: float = 360.0) -> Button:
	var b := Button.new()
	b.text = text.to_upper()
	b.custom_minimum_size = Vector2(width, 54)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b.add_theme_font_size_override("font_size", 16)
	b.add_theme_color_override("font_color", Color("#e8e0d9"))
	b.add_theme_color_override("font_hover_color", Color("#fff5eb"))
	b.add_theme_color_override("font_pressed_color", Color("#ffffff"))
	b.add_theme_color_override("font_disabled_color", Color("#71696a"))
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color("#171518")
	normal.border_width_left = 3
	normal.border_width_top = 1
	normal.border_width_right = 1
	normal.border_width_bottom = 1
	normal.border_color = Color("#704047")
	normal.content_margin_left = 18
	normal.content_margin_right = 18
	normal.content_margin_top = 12
	normal.content_margin_bottom = 12
	var hover := normal.duplicate()
	hover.bg_color = Color("#2b191d")
	hover.border_color = Color("#c14b54")
	var pressed := normal.duplicate()
	pressed.bg_color = Color("#3a1c21")
	pressed.border_color = Color("#e05a60")
	var disabled := normal.duplicate()
	disabled.bg_color = Color("#171719")
	disabled.border_color = Color("#383236")
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("focus", hover)
	b.add_theme_stylebox_override("disabled", disabled)
	b.pressed.connect(_play_sfx.bind("ui_tick"))
	b.pressed.connect(callback)
	parent.add_child(b)
	return b

func _show_disclaimer() -> void:
	if ambience_player != null:
		ambience_player.stop()
	_clear_screen()
	var backdrop := ColorRect.new()
	backdrop.color = Color("#050505")
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen_root.add_child(backdrop)
	var warning_title := _label(screen_root, "ДИСКЛЕЙМЕР", Vector2(300, 105), Vector2(680, 54), 34, Color("#b83232"))
	warning_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var body := RichTextLabel.new()
	body.position = Vector2(205, 190)
	body.size = Vector2(870, 340)
	body.bbcode_enabled = true
	body.fit_content = false
	body.scroll_active = false
	body.add_theme_font_size_override("normal_font_size", 19)
	body.add_theme_color_override("default_color", Color("#d9d5d0"))
	body.add_theme_constant_override("line_separation", 10)
	body.text = "[center]Действие игры разворачивается в Казани конца 1970-х — середины 1980-х годов.[/center]\n\n" + \
		"Это художественное произведение. Главный герой, его окружение и многие сюжетные ситуации вымышлены. Отдельные элементы основаны на исторических реалиях эпохи; художественный сюжет не является документальной хроникой.\n\n" + \
		"В игре затрагиваются темы уличного насилия, преступности, давления сверстников, конфликтов и тяжёлых социальных обстоятельств.\n\n" + \
		"[b][color=#d75a50]Не повторяйте опасные и противоправные поступки персонажей в реальной жизни.[/color][/b] Игра не призывает к насилию и не оправдывает преступления."
	screen_root.add_child(body)
	var rule := ColorRect.new()
	rule.color = Color("#713333")
	rule.position = Vector2(340, 565)
	rule.size = Vector2(600, 1)
	screen_root.add_child(rule)
	var accept := _button(screen_root, "ПРОДОЛЖИТЬ", _leave_disclaimer, 300)
	accept.position = Vector2(490, 595)
	var footer := _label(screen_root, "КАЗАНЬ · ДРУГОЕ ВРЕМЯ · ДРУГИЕ ПРАВИЛА", Vector2(300, 675), Vector2(680, 22), 11, Color("#766b68"))
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

func _leave_disclaimer() -> void:
	settings["disclaimer_version"] = 1
	SaveManager.save_settings(settings)
	var fade := _make_fade_overlay(0.0)
	await _fade_to(fade, 1.0, 0.9)
	_show_title()
	var title_fade := _make_fade_overlay(1.0)
	await _fade_to(title_fade, 0.0, 1.1)

func _show_title() -> void:
	if ambience_player != null:
		ambience_player.stop()
	_play_main_theme()
	_clear_screen()
	var bg := TextureRect.new()
	var title_texture := load(BG_DIR + "winter_street_reference.jpg") as Texture2D
	if title_texture:
		bg.texture = title_texture
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.modulate = Color(0.58, 0.61, 0.64, 1)
	bg.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	screen_root.add_child(bg)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.014, 0.018, 0.48)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen_root.add_child(shade)
	var left_shade := ColorRect.new()
	left_shade.color = Color(0.025, 0.018, 0.022, 0.80)
	left_shade.position = Vector2(0, 0)
	left_shade.size = Vector2(610, 720)
	screen_root.add_child(left_shade)
	var red_rule := ColorRect.new()
	red_rule.color = Color("#a9323c")
	red_rule.position = Vector2(82, 126)
	red_rule.size = Vector2(4, 455)
	screen_root.add_child(red_rule)
	var eyebrow := _label(screen_root, "КАЗАНЬ · НОЯБРЬ 1981", Vector2(112, 126), Vector2(420, 28), 14, Color("#c36a6e"))
	eyebrow.add_theme_font_size_override("font_size", 14)
	var title := _label(screen_root, "КАЗАНЬ:\nУЛИЦЫ", Vector2(105, 168), Vector2(470, 150), 58, Color("#f0e9e2"))
	title.add_theme_font_size_override("font_size", 62)
	var subtitle := _label(screen_root, "ГОРОД НЕ СПРАШИВАЕТ, ГОТОВ ЛИ ТЫ.", Vector2(112, 332), Vector2(450, 34), 15, Color("#b99a96"))
	var divider := ColorRect.new()
	divider.color = Color("#694047")
	divider.position = Vector2(112, 378)
	divider.size = Vector2(390, 1)
	screen_root.add_child(divider)
	var menu := VBoxContainer.new()
	menu.position = Vector2(112, 405)
	menu.size = Vector2(390, 240)
	menu.add_theme_constant_override("separation", 9)
	screen_root.add_child(menu)
	_button(menu, "Новая игра", _new_game, 390)
	_button(menu, "Продолжить", _continue_game, 390)
	_button(menu, "Настройки", _show_settings, 390)
	_button(menu, "Выход", _quit_game, 390)
	var edition := _label(screen_root, "СЮЖЕТНАЯ ИГРА · КАЗАНЬ НАЧАЛА 1980-Х", Vector2(112, 670), Vector2(500, 22), 11, Color("#887b79"))
	var right_note := _label(screen_root, "1981", Vector2(1080, 625), Vector2(120, 45), 26, Color("#d0c1b8"))
	right_note.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

func _new_game() -> void:
	_stop_main_theme()
	state.reset()
	_show_character_creation()

func _show_character_creation() -> void:
	_clear_screen()
	_label(screen_root, "ГЛАВНЫЙ ГЕРОЙ", Vector2(70, 55), Vector2(1100, 55), 34)
	_panel(screen_root, Rect2(75, 145, 500, 250), Color("#20292d"), 12)
	_label(screen_root, "АЛЕКСЕЙ КУЗНЕЦОВ", Vector2(105, 175), Vector2(430, 52), 29, Color("#e5ded0"))
	_label(screen_root, "15 ЛЕТ", Vector2(108, 235), Vector2(200, 35), 20, Color("#d6b98a"))
	_label(screen_root, "Погоняло «Кузнец» появится позже —\nесли Алексей заслужит его в группировке.", Vector2(108, 285), Vector2(420, 70), 17, Color("#aeb6b5"))
	_label(screen_root, "Где начинается твоя история?", Vector2(650, 165), Vector2(500, 35), 18)
	var origin := OptionButton.new()
	origin.position = Vector2(650, 205)
	origin.size = Vector2(420, 48)
	for item in ["Теплоконтроль", "Аметьево", "Центр", "Соцгород", "Дербышки", "Горки"]:
		origin.add_item(item)
	screen_root.add_child(origin)
	_label(screen_root, "Имя, фамилия и возраст героя закреплены сюжетом.\nМеняется только район, с которого начнётся история.", Vector2(650, 280), Vector2(470, 75), 16, Color("#aeb6b5"))
	_button(screen_root, "Начать историю", func():
		state.data.hero_name = "Алексей"
		state.data.hero_surname = "Кузнецов"
		state.data.hero_age = 15
		state.data.hero_nickname = ""
		state.data.hero_group_joined = false
		state.data.hero_nickname_unlocked = false
		state.data.origin = origin.get_item_text(origin.selected)
		var origin_ids := {"Теплоконтроль":"teplokontrol", "Аметьево":"ametyevo", "Центр":"center", "Соцгород":"sotsgorod", "Дербышки":"derbyshki", "Горки":"gorki"}
		state.data.current_district = str(origin_ids.get(state.data.origin, "teplokontrol"))
		state.add_journal("Алексею Кузнецову пятнадцать лет. Его история в Казани начинается в районе: %s." % state.data.origin)
		_open_scene("intro_yard")
	, 360).position = Vector2(80, 440)
	status_label = _label(screen_root, "", Vector2(80, 510), Vector2(800, 40), 16, Color("#d58c72"))
	_button(screen_root, "Назад", _show_title, 180).position = Vector2(80, 590)

func _continue_game() -> void:
	_stop_main_theme()
	if ambience_player != null:
		ambience_player.stop()
	_show_save_slots("load")

func _show_save_slots(mode: String) -> void:
	_clear_screen()
	var heading := "СОХРАНЕНИЯ" if mode == "load" else "СОХРАНИТЬ ИГРУ"
	_label(screen_root, heading, Vector2(55, 45), Vector2(1000, 55), 34)
	_label(screen_root, "Три независимых слота. Автосохранение использует слот 1.", Vector2(58, 100), Vector2(1100, 32), 16, Color("#aeb6b5"))
	for slot in range(1, SaveManager.MAX_SLOTS + 1):
		var selected_slot := slot
		var exists := SaveManager.has_save(selected_slot)
		var slot_text := "Слот %d · %s" % [slot, "сохранение найдено" if exists else "пустой"]
		var b := _button(screen_root, slot_text, func():
			if mode == "load":
				_load_slot(selected_slot)
			else:
				_save_slot(selected_slot)
		, 650)
		b.position = Vector2(70, 175 + (slot - 1) * 90)
		if mode == "load" and not exists:
			b.disabled = true
	var back_action: Callable = _show_title
	if mode != "load":
		back_action = _restore_after_save
	_button(screen_root, "Назад", back_action, 200).position = Vector2(70, 500)

func _load_slot(slot: int) -> void:
	if not SaveManager.load_game(state, slot):
		_show_save_slots("load")
		return
	if str(state.data.scene_id) == "map":
		_show_map()
	else:
		_open_scene(str(state.data.scene_id), int(state.data.get("line_index", 0)))

func _save_slot(slot: int) -> void:
	if SaveManager.save_game(state, slot):
		_restore_after_save()

func _restore_after_save() -> void:
	if str(state.data.scene_id) == "map":
		_show_map()
	else:
		_show_dialogue()

func _open_scene(scene_id: String, restore_line: int = 0) -> void:
	if scene_id.begins_with("ending_"):
		_play_main_theme(true)
	if not story.get("scenes", {}).has(scene_id):
		_show_map()
		return
	state.data.scene_id = scene_id
	current_scene = story.scenes[scene_id]
	_set_scene_ambience(current_scene)
	_sync_scene_clock(current_scene)
	var chapter_number := int(current_scene.get("chapter", 0))
	if chapter_number > 0:
		state.data.chapter = chapter_number
		var history: Array = state.data.get("chapter_history", [])
		if not history.has(chapter_number):
			history.append(chapter_number)
		state.data.chapter_history = history
	line_index = clampi(restore_line, 0, current_scene.get("lines", []).size())
	state.data.line_index = line_index
	state.mark_visited(str(current_scene.get("location", scene_id)))
	SaveManager.save_game(state)
	_show_dialogue()

func _sync_scene_clock(scene_data: Dictionary) -> void:
	var raw := str(scene_data.get("time", ""))
	var month_names := {"января":1,"февраля":2,"марта":3,"апреля":4,"мая":5,"июня":6,"июля":7,"августа":8,"сентября":9,"октября":10,"ноября":11,"декабря":12}
	var regex := RegEx.new()
	regex.compile("(\\d{1,2}) ([А-Яа-я]+) (\\d{4}),? (\\d{1,2}):(\\d{2})")
	var result := regex.search(raw)
	if result:
		var month_name := result.get_string(2).to_lower()
		if month_names.has(month_name):
			var target_day := int(result.get_string(1))
			var target_month := int(month_names[month_name])
			var target_year := int(result.get_string(3))
			var target_hour := int(result.get_string(4))
			var target_minute := int(result.get_string(5))
			var target_stamp := target_year * 100000000 + target_month * 1000000 + target_day * 10000 + target_hour * 100 + target_minute
			var current_stamp := int(state.data.year) * 100000000 + int(state.data.month) * 1000000 + int(state.data.day) * 10000 + int(state.data.hour) * 100 + int(state.data.minute)
			# Сюжетная метка задаёт нижнюю границу времени. Свободные действия игрока не должны
			# откатывать часы назад при переходе к следующей реплике/сцене.
			if target_stamp > current_stamp:
				state.data.day = target_day
				state.data.month = target_month
				state.data.year = target_year
				state.data.hour = target_hour
				state.data.minute = target_minute
	else:
		var clock := RegEx.new()
		clock.compile("(\\d{1,2}):(\\d{2})")
		var clock_result := clock.search(raw)
		if clock_result:
			var target_hour := int(clock_result.get_string(1))
			var target_minute := int(clock_result.get_string(2))
			var target_clock := target_hour * 60 + target_minute
			var current_clock := int(state.data.hour) * 60 + int(state.data.minute)
			if target_clock > current_clock:
				state.data.hour = target_hour
				state.data.minute = target_minute

func _show_dialogue() -> void:
	_clear_screen()
	var bg := ColorRect.new()
	bg.color = Color("#111216")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen_root.add_child(bg)

	var background_key := str(current_scene.get("background", "courtyard_winter"))
	var image_path := BG_DIR + background_key + "_reference.jpg"
	if not ResourceLoader.exists(image_path):
		image_path = BG_DIR + "courtyard_winter_reference.jpg"
	if ResourceLoader.exists(image_path):
		var tex := load(image_path) as Texture2D
		if tex:
			var image := TextureRect.new()
			image.texture = tex
			image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
			image.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
			image.modulate = Color(0.72, 0.70, 0.70, 1)
			image.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
			screen_root.add_child(image)

	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.012, 0.018, 0.24)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen_root.add_child(shade)

	var date_text := _label(screen_root, "%s  ·  %02d:%02d" % [current_scene.get("time", "26 ноября 1981"), state.data.hour, state.data.minute], Vector2(28, 16), Vector2(620, 26), 13, Color("#c9bfba"))
	date_text.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))

	# Character portrait stays large and grounded on the left, matching the approved reference.
	character_shadow = TextureRect.new()
	character_shadow.position = Vector2(-34, -12)
	character_shadow.size = Vector2(690, 750)
	character_shadow.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	character_shadow.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	character_shadow.modulate = Color(0.01, 0.008, 0.01, 0.30)
	character_shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	character_shadow.visible = false
	screen_root.add_child(character_shadow)

	character_portrait = TextureRect.new()
	character_portrait.position = Vector2(-38, -14)
	character_portrait.size = Vector2(690, 750)
	character_portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	character_portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	character_portrait.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	character_portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
	character_portrait.visible = false
	screen_root.add_child(character_portrait)

	# Wide, nearly black translucent dialogue plate with a fine irregular red frame.
	var dialogue_plate := NinePatchRect.new()
	dialogue_plate.texture = load("res://assets/ui/dialogue.png")
	dialogue_plate.position = Vector2(164, 520)
	dialogue_plate.size = Vector2(1088, 172)
	dialogue_plate.patch_margin_left = 72
	dialogue_plate.patch_margin_top = 48
	dialogue_plate.patch_margin_right = 72
	dialogue_plate.patch_margin_bottom = 48
	dialogue_plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen_root.add_child(dialogue_plate)

	# Invisible tap area lets the player advance by tapping the dialogue itself.
	var advance_area := Button.new()
	advance_area.position = Vector2(178, 530)
	advance_area.size = Vector2(900, 132)
	advance_area.flat = true
	advance_area.focus_mode = Control.FOCUS_NONE
	advance_area.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	for state_name in ["normal", "hover", "pressed", "focus"]:
		var empty_style := StyleBoxEmpty.new()
		advance_area.add_theme_stylebox_override(state_name, empty_style)
	advance_area.add_theme_color_override("font_color", Color(0, 0, 0, 0))
	advance_area.add_theme_color_override("font_hover_color", Color(0, 0, 0, 0))
	advance_area.pressed.connect(_next_line)
	advance_area.pressed.connect(_play_sfx.bind("ui_tick"))
	screen_root.add_child(advance_area)

	var speaker_plate := NinePatchRect.new()
	speaker_plate.texture = load("res://assets/ui/nameplate.png")
	speaker_plate.position = Vector2(202, 482)
	speaker_plate.size = Vector2(145, 52)
	speaker_plate.patch_margin_left = 48
	speaker_plate.patch_margin_top = 24
	speaker_plate.patch_margin_right = 48
	speaker_plate.patch_margin_bottom = 24
	speaker_plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen_root.add_child(speaker_plate)

	speaker_label = _label(screen_root, "", Vector2(210, 490), Vector2(130, 34), 21, Color("#c9434d"))
	speaker_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	speaker_label.add_theme_font_override("font", ThemeDB.fallback_font)
	dialogue_label = RichTextLabel.new()
	dialogue_label.position = Vector2(212, 555)
	dialogue_label.size = Vector2(820, 88)
	dialogue_label.bbcode_enabled = true
	dialogue_label.fit_content = false
	dialogue_label.scroll_active = false
	dialogue_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dialogue_label.add_theme_font_size_override("normal_font_size", 22)
	dialogue_label.add_theme_color_override("default_color", Color("#e5ded9"))
	dialogue_label.add_theme_constant_override("line_separation", 7)
	screen_root.add_child(dialogue_label)

	choices_box = VBoxContainer.new()
	choices_box.position = Vector2(760, 250)
	choices_box.size = Vector2(440, 245)
	choices_box.add_theme_constant_override("separation", 5)
	screen_root.add_child(choices_box)

	# Quiet text-only controls sit inside the lower-right edge of the plaque.
	_add_dialogue_footer("Журнал", Vector2(790, 665), 62, _show_journal)
	_add_dialogue_footer("Сохранить", Vector2(862, 665), 78, _save_current)
	_add_dialogue_footer("Загрузить", Vector2(950, 665), 72, func(): _show_save_slots("load"))
	_add_dialogue_footer("Настройки", Vector2(1032, 665), 78, _show_settings)
	_add_dialogue_footer("Карта", Vector2(1116, 665), 52, _show_map)
	var next_mark := Button.new()
	next_mark.text = "▶"
	next_mark.position = Vector2(1190, 653)
	next_mark.size = Vector2(38, 34)
	next_mark.flat = true
	next_mark.focus_mode = Control.FOCUS_NONE
	next_mark.add_theme_font_size_override("font_size", 20)
	next_mark.add_theme_color_override("font_color", Color("#b62f3b"))
	next_mark.add_theme_color_override("font_hover_color", Color("#ed5963"))
	next_mark.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
	next_mark.add_theme_stylebox_override("hover", StyleBoxEmpty.new())
	next_mark.add_theme_stylebox_override("pressed", StyleBoxEmpty.new())
	next_mark.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	next_mark.pressed.connect(_next_line)
	next_mark.pressed.connect(_play_sfx.bind("ui_tick"))
	screen_root.add_child(next_mark)
	_render_line()

func _add_dialogue_footer(text_value: String, position_value: Vector2, width_value: float, callback: Callable) -> void:
	var item := Button.new()
	item.text = text_value
	item.position = position_value
	item.size = Vector2(width_value, 22)
	item.flat = true
	item.focus_mode = Control.FOCUS_NONE
	item.add_theme_font_size_override("font_size", 11)
	item.add_theme_color_override("font_color", Color("#8f8582"))
	item.add_theme_color_override("font_hover_color", Color("#d5c5bf"))
	item.add_theme_color_override("font_pressed_color", Color("#c9434d"))
	item.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
	item.add_theme_stylebox_override("hover", StyleBoxEmpty.new())
	item.add_theme_stylebox_override("pressed", StyleBoxEmpty.new())
	item.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	item.pressed.connect(callback)
	item.pressed.connect(_play_sfx.bind("ui_tick"))
	screen_root.add_child(item)

func _render_line() -> void:
	for child in choices_box.get_children():
		child.queue_free()
	var lines: Array = current_scene.get("lines", [])
	if line_index < lines.size():
		var line: Dictionary = lines[line_index]
		var displayed_speaker := str(line.get("speaker", ""))
		if displayed_speaker == "Алексей":
			displayed_speaker = "Кузнец" if bool(state.data.get("hero_group_joined", false)) else "Лёха"
		speaker_label.text = displayed_speaker
		dialogue_label.text = str(line.get("text", ""))
		_update_character_portrait(speaker_label.text, str(line.get("text", "")))
	else:
		speaker_label.text = ""
		dialogue_label.text = ""
		character_portrait.visible = false
		var choices: Array = current_scene.get("choices", [])
		if choices.is_empty():
			_dialogue_choice_button(choices_box, "На карту города", _show_map)
		else:
			var visible_count := 0
			for choice in choices:
				var selected_choice: Dictionary = choice
				if not _choice_available(selected_choice):
					continue
				visible_count += 1
				_dialogue_choice_button(choices_box, str(selected_choice.get("text", "Продолжить")), func(): _choose(selected_choice))
			if visible_count == 0:
				_dialogue_choice_button(choices_box, "Вернуться к карте", _show_map)

func _update_character_portrait(speaker: String, line_text: String = "") -> void:
	if character_portrait == null:
		return
	var portrait_key := ""
	match speaker:
		"Алексей", "Алексей Кузнецов", "Лёха", "Лёша", "Кузнец": portrait_key = "alexey"
		"Марат": portrait_key = "marat"
		"Сеня": portrait_key = "senya"
		"Галина Петровна": portrait_key = "galya"
		"Мастер", "Кадровик", "Кладовщик": portrait_key = "foreman"
		"Грузчик", "Рабочий": portrait_key = "mechanic"
		"Кондуктор": portrait_key = "conductor"
		"Незнакомец": portrait_key = "pavel"
		"Незнакомый парень": portrait_key = "kolya"
		"Организатор клуба", "Руководитель кружка": portrait_key = "zoya"
		"Сосед": portrait_key = "veteran"
		"Сотрудник": portrait_key = "courier"
		"Сотрудница домоуправления": portrait_key = "clerk"
		"Ирина": portrait_key = "irina"
		"Андрей": portrait_key = "andrey"
		"Тамара Ивановна": portrait_key = "tamara"
		"Старший сержант": portrait_key = "sergeant"
		"Елена Викторовна": portrait_key = "doctor"
		"Пётр Семёнович": portrait_key = "old_worker"
		"Николай Андреевич": portrait_key = "railway_worker"
		"Борис": portrait_key = "driver"
		"Сашка": portrait_key = "teen_boy"
		"Колька": portrait_key = "kolya"
		_: portrait_key = ""
	if portrait_key.is_empty():
		character_portrait.visible = false
		character_shadow.visible = false
		return
	var portrait_path := ""
	if portrait_key == "alexey":
		var emotion := _infer_alexey_emotion(line_text)
		portrait_path = "res://assets/characters_vn/alexey_%s.png" % emotion
	if portrait_path.is_empty() or not ResourceLoader.exists(portrait_path):
		portrait_path = "res://assets/characters_clean/%s.png" % portrait_key
	if ResourceLoader.exists(portrait_path):
		character_portrait.texture = load(portrait_path) as Texture2D
		character_shadow.texture = character_portrait.texture
		character_portrait.visible = character_portrait.texture != null
		character_shadow.visible = character_portrait.visible
		if character_portrait.visible:
			character_portrait.modulate.a = 0.0
			var portrait_tween := create_tween()
			portrait_tween.tween_property(character_portrait, "modulate:a", 1.0, 0.18)

func _infer_alexey_emotion(line_text: String) -> String:
	var t := line_text.to_lower()
	if t.contains("страш") or t.contains("боюсь") or t.contains("не надо") or t.contains("помогите"):
		return "afraid"
	if t.contains("ненавиж") or t.contains("отвали") or t.contains("заткнись") or t.contains("пошёл") or t.contains("пошел"):
		return "angry"
	if t.contains("прости") or t.contains("жаль") or t.contains("один") or t.contains("не хочу"):
		return "sad"
	if t.contains("что?") or t.contains("чего?") or t.contains("серьёзно") or t.contains("серьезно") or t.contains("не может быть"):
		return "shocked"
	if t.contains("ха") or t.contains("смешно") or t.contains("ну да") or t.contains("ага, конечно"):
		return "smirk"
	return "neutral"

func _next_line() -> void:
	_play_sfx("paper_swish")
	line_index += 1
	state.data.line_index = line_index
	_render_line()

func _choose(choice: Dictionary) -> void:
	var choice_text := str(choice.get("text", "")).to_lower()
	if choice_text.contains("уйти") or choice_text.contains("драться") or choice_text.contains("риск") or choice_text.contains("угроз"):
		_play_sfx("heartbeat")
	_apply_effects(choice.get("effects", {}))
	if choice.has("action"):
		match str(choice.action):
			"map": _show_map()
			"journal": _show_journal()
			"main_menu": _show_title()
		return
	_open_scene(str(choice.get("next", "chapter1_end")))


func _choice_available(choice: Dictionary) -> bool:
	var requirements: Dictionary = choice.get("requires", {})
	if requirements.has("group_joined") and bool(state.data.get("hero_group_joined", false)) != bool(requirements.group_joined):
		return false
	for flag_name in requirements.get("flags", {}):
		if state.get_flag(str(flag_name)) != requirements.flags[flag_name]:
			return false
	for character_id in requirements.get("relations_min", {}):
		if int(state.data.relationships.get(character_id, 0)) < int(requirements.relations_min[character_id]):
			return false
	for stat_name in requirements.get("stats_min", {}):
		if int(state.data.get(stat_name, 0)) < int(requirements.stats_min[stat_name]):
			return false
	for quest_id in requirements.get("quests", {}):
		if str(state.data.quests.get(quest_id, "locked")) != str(requirements.quests[quest_id]):
			return false
	for item_id in requirements.get("items", []):
		if not state.has_item(str(item_id)):
			return false
	return true

func _apply_effects(effects: Dictionary) -> void:
	for key in effects.get("flags", {}):
		state.set_flag(str(key), effects.flags[key])
	if effects.has("group_joined"):
		state.set_group_membership(bool(effects.group_joined))
	if effects.has("unlock_nickname") and bool(effects.unlock_nickname):
		state.unlock_hero_nickname("Кузнец")
	for key in effects.get("relations", {}):
		state.change_relation(str(key), int(effects.relations[key]))
	for key in effects.get("stats", {}):
		state.change_stat(str(key), int(effects.stats[key]))
	for item_id in effects.get("items_add", []):
		state.add_item(str(item_id))
	for item_id in effects.get("items_remove", []):
		state.remove_item(str(item_id))
	if effects.has("time"):
		state.advance_time(int(effects.time))
	if effects.has("journal"):
		state.add_journal(str(effects.journal))
	for key in effects.get("quests", {}):
		state.set_quest(str(key), str(effects.quests[key]))
	if effects.has("ending"):
		state.data.ending = str(effects.ending)
	SaveManager.save_game(state)

func _show_map() -> void:
	state.data.scene_id = "map"
	SaveManager.save_game(state)
	_clear_screen()
	var bg := ColorRect.new()
	bg.color = Color("#141a1d")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen_root.add_child(bg)
	_label(screen_root, "КАЗАНЬ · КАРТА РАЙОНОВ", Vector2(40, 24), Vector2(900, 50), 32)
	_label(screen_root, "Выбери район. Схема условная; время перехода — игровой расчёт, не историческое расписание.", Vector2(44, 78), Vector2(930, 35), 14, Color("#9da6a7"))
	_label(screen_root, "%02d.%02d.%04d · %02d:%02d" % [int(state.data.day), int(state.data.month), int(state.data.year), int(state.data.hour), int(state.data.minute)], Vector2(900, 24), Vector2(300, 32), 17, Color("#d6b98a"))
	_button(screen_root, "Транспорт 1981", _show_transport, 190).position = Vector2(1020, 75)
	var map_panel := _panel(screen_root, Rect2(40, 130, 820, 530), Color("#20292d"), 12)
	# Схематичная речная линия и дорожные оси — художественная навигационная схема.
	var river := ColorRect.new()
	river.color = Color("#344b54")
	river.position = Vector2(30, 245)
	river.size = Vector2(740, 22)
	river.rotation = -0.13
	map_panel.add_child(river)
	for district in MapData.DISTRICTS:
		var district_id := str(district.id)
		var b := Button.new()
		b.text = str(district.name)
		b.position = Vector2(float(district.x) * 760.0 - 35.0, float(district.y) * 460.0 - 20.0)
		b.custom_minimum_size = Vector2(170, 44)
		b.add_theme_font_size_override("font_size", 14)
		b.add_theme_color_override("font_color", Color("#e8e0d9"))
		var district_style := StyleBoxFlat.new()
		district_style.bg_color = Color("#21191c")
		district_style.border_width_left = 2
		district_style.border_width_top = 1
		district_style.border_width_right = 1
		district_style.border_width_bottom = 1
		district_style.border_color = Color("#8d4148")
		district_style.content_margin_left = 8
		district_style.content_margin_right = 8
		b.add_theme_stylebox_override("normal", district_style)
		var district_hover := district_style.duplicate()
		district_hover.bg_color = Color("#42252a")
		district_hover.border_color = Color("#d15a61")
		b.add_theme_stylebox_override("hover", district_hover)
		b.add_theme_stylebox_override("pressed", district_hover)
		b.pressed.connect(func(): _show_district(district_id))
		map_panel.add_child(b)
	var side := _panel(screen_root, Rect2(890, 130, 350, 530), Color("#20292d"), 12)
	_label(side, "ТВОЁ СОСТОЯНИЕ", Vector2(12, 12), Vector2(300, 32), 19, Color("#d6b98a"))
	_label(side, state.hero_display_name(), Vector2(12, 58), Vector2(300, 30), 18)
	_label(side, "Возраст: %d лет" % int(state.data.get("hero_age", 15)), Vector2(12, 88), Vector2(300, 24), 14, Color("#aeb6b5"))
	_label(side, "Наличные: %d руб." % int(state.data.cash), Vector2(12, 118), Vector2(300, 30), 16)
	_label(side, "Здоровье: %d/100" % int(state.data.health), Vector2(12, 153), Vector2(300, 30), 16)
	_label(side, "Силы: %d/100" % int(state.data.get("energy", 100)), Vector2(12, 183), Vector2(300, 30), 16, Color("#d6b98a"))
	_label(side, "Сытость: %d/100" % int(state.data.get("hunger", 100)), Vector2(12, 213), Vector2(300, 30), 16)
	_label(side, "Репутация: %d" % int(state.data.reputation), Vector2(12, 243), Vector2(300, 30), 16)
	_label(side, "Время: %02d:%02d" % [int(state.data.hour), int(state.data.minute)], Vector2(12, 273), Vector2(300, 25), 15, Color("#aeb6b5"))
	_label(side, "Знакомства", Vector2(12, 303), Vector2(300, 30), 18, Color("#d6b98a"))
	var relationship_names := {"marat":"Марат", "senya":"Сеня", "galya":"Галина Петровна"}
	for i in ["marat", "senya", "galya"]:
		_label(side, "%s: %d" % [relationship_names[i], int(state.data.relationships.get(i, 0))], Vector2(12, 338 + ( ["marat", "senya", "galya"].find(i) * 30)), Vector2(300, 26), 14)
	_button(side, "Журнал", _show_journal, 300).position = Vector2(12, 435)
	_button(side, "Сохранить", _save_current, 300).position = Vector2(12, 490)
	_button(side, "История группировок", _show_historical_groups, 300).position = Vector2(12, 545)


func _show_historical_groups() -> void:
	_clear_screen()
	_label(screen_root, "ИСТОРИЯ КАЗАНСКИХ ГРУППИРОВОК", Vector2(38, 20), Vector2(1160, 48), 29)
	_label(screen_root, "Историческая справка · конец 1960-х — 1982 год · документированные сведения отделены от художественного сюжета", Vector2(42, 68), Vector2(1180, 34), 13, Color("#aeb6b5"))
	var file := FileAccess.open("res://data/historical_groups.json", FileAccess.READ)
	var parsed: Variant = JSON.parse_string(file.get_as_text()) if file else null
	var groups: Array = parsed.get("groups", []) if parsed is Dictionary else []
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(38, 112)
	scroll.size = Vector2(1180, 490)
	screen_root.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 9)
	scroll.add_child(list)
	for group in groups:
		if not group is Dictionary:
			continue
		var card := _panel(list, Rect2(0, 0, 1130, 158), Color("#242d31"), 8)
		_label(card, str(group.get("name", "")), Vector2(14, 8), Vector2(1080, 28), 18, Color("#d6b98a"))
		_label(card, str(group.get("period", "")) + " · " + str(group.get("area", "")), Vector2(14, 40), Vector2(1080, 25), 13, Color("#c3c9c7"))
		_label(card, str(group.get("description", "")), Vector2(14, 68), Vector2(1080, 38), 13, Color("#aeb6b5"))
		_label(card, "В игре: " + str(group.get("status_in_game_1981", "")), Vector2(14, 108), Vector2(1080, 24), 12, Color("#d58c72"))
		_label(card, "Надёжность: " + str(group.get("confidence", "")), Vector2(14, 132), Vector2(1080, 22), 11, Color("#9da6a7"))
	var note := _panel(screen_root, Rect2(38, 610, 1180, 48), Color("#321f20"), 6)
	_label(note, "Источники: Л. Агеева (1991); пособие КФУ (2015); Р. Гараев (2024). «Тяп-Ляп»: дело рассмотрено в апреле 1980 года; к 1981-му — историческое прошлое.", Vector2(10, 7), Vector2(1150, 34), 12, Color("#e0b8ae"))
	_button(screen_root, "Назад к карте", _show_map, 220).position = Vector2(40, 670)

func _show_district(district_id: String) -> void:
	_play_sfx("footstep_snow")
	var previous_district := str(state.data.get("current_district", district_id))
	if previous_district != district_id:
		var travel_minutes := _district_travel_minutes(previous_district, district_id)
		state.advance_time(travel_minutes)
		state.add_journal("Дорога между районами заняла около %d минут." % travel_minutes)
	state.data.current_district = district_id
	_clear_screen()
	var district_name := district_id.capitalize()
	for d in MapData.DISTRICTS:
		if d.id == district_id:
			district_name = str(d.name)
	_label(screen_root, district_name.to_upper(), Vector2(45, 30), Vector2(900, 50), 32)
	_label(screen_root, "Выбери точку района", Vector2(48, 90), Vector2(900, 35), 17, Color("#aeb6b5"))
	var points: Array = MapData.LOCATIONS.get(district_id, [])
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(55, 145)
	scroll.size = Vector2(1120, 450)
	screen_root.add_child(scroll)
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 10)
	scroll.add_child(box)
	for point in points:
		var point_name := str(point.name)
		var point_description := str(point.description)
		var point_id := str(point.id)
		var point_scene_id := str(point.get("scene", ""))
		var visited: bool = state.data.visited.has(point_id)
		var p := _panel(box, Rect2(0, 0, 900, 105), Color("#20292d"), 8)
		_label(p, ("✓ " if visited else "") + point_name, Vector2(12, 8), Vector2(640, 30), 19, Color("#d6b98a"))
		_label(p, point_description, Vector2(12, 43), Vector2(850, 35), 15, Color("#d6d6d0"))
		_button(p, "Осмотреть", func(): _visit_location(point_name, point_description, point_id, point_scene_id), 180).position = Vector2(680, 8)
	_button(screen_root, "Назад к карте", _show_map, 220).position = Vector2(55, 610)

func _visit_location(location_name: String, description: String, location_id: String = "", scene_id: String = "") -> void:
	_play_sfx("door_stairwell" if location_id == "house_entrance" else "footstep_snow")
	if not scene_id.is_empty() and story.get("scenes", {}).has(scene_id):
		_open_scene(scene_id)
		return
	current_location_name = location_name
	current_location_description = description
	current_location_id = location_id
	current_location_kind = _location_kind(location_id)
	var first_visit: bool = not state.data.visited.has(location_id if not location_id.is_empty() else location_name)
	state.mark_visited(location_id if not location_id.is_empty() else location_name)
	if first_visit:
		state.advance_time(10)
		state.add_journal("Ты впервые осмотрел место: %s." % location_name)
	_show_location_menu()

func _show_location_menu() -> void:
	_clear_screen()
	_label(screen_root, current_location_name.to_upper(), Vector2(55, 35), Vector2(1050, 48), 30)
	var card := _panel(screen_root, Rect2(55, 105, 1120, 170), Color("#20292d"), 10)
	_label(card, current_location_description, Vector2(18, 15), Vector2(1070, 85), 19)
	_label(card, "Дата: %02d.%02d.%04d · %02d:%02d · Силы: %d/100 · Сытость: %d/100 · Наличные: %d руб." % [int(state.data.day), int(state.data.month), int(state.data.year), int(state.data.hour), int(state.data.minute), int(state.data.get("energy", 100)), int(state.data.get("hunger", 100)), int(state.data.cash)], Vector2(18, 112), Vector2(1080, 30), 14, Color("#d6b98a"))
	var actions := _panel(screen_root, Rect2(55, 300, 1120, 280), Color("#20292d"), 10)
	_label(actions, "ЧТО ДЕЛАТЬ", Vector2(18, 12), Vector2(500, 30), 20, Color("#d6b98a"))
	_button(actions, "Осмотреться · 10 минут", _action_look_around, 320).position = Vector2(18, 58)
	_button(actions, "Передохнуть · 30 минут", _action_rest, 320).position = Vector2(365, 58)
	var roam_event: Dictionary = MapData.ROAM_EVENTS.get(current_location_id, {})
	if not roam_event.is_empty() and not bool(state.get_flag(_roam_event_flag(str(roam_event.id)), false)):
		var event_button := _button(actions, "Ситуация: %s" % str(roam_event.title), func(): _show_roam_event(str(roam_event.id)), 320)
		event_button.position = Vector2(710, 58)
	if current_location_kind == "shop":
		var buy_button := _button(actions, "Купить хлеб · 1 рубль", _action_buy_bread, 320)
		buy_button.position = Vector2(18, 122)
		buy_button.disabled = int(state.data.cash) < 1 or state.has_item("хлеб")
	if current_location_id == "canteen":
		var meal_button := _button(actions, "Купить горячий обед · 2 рубля", _action_buy_meal, 320)
		meal_button.position = Vector2(365, 122)
		meal_button.disabled = int(state.data.cash) < 2 or state.has_item("обед")
	var job := _odd_job_for_location(current_location_id)
	if not job.is_empty():
		var job_flag := _odd_job_flag(current_location_id)
		var job_button := _button(actions, "Разовая помощь · +%d руб." % int(job.get("reward", 1)), func(): _show_odd_job(current_location_id), 320)
		job_button.position = Vector2(710, 122)
		job_button.disabled = bool(state.get_flag(job_flag, false)) or int(state.data.energy) < int(job.get("energy", 5))
	if current_location_kind == "home":
		var sleep_button := _button(actions, "Лечь спать · 8 часов", _action_sleep, 320)
		sleep_button.position = Vector2(18, 122)
		sleep_button.disabled = int(state.data.energy) >= 96 and int(state.data.hour) < 21 and int(state.data.hour) >= 7
	if current_location_id == "library":
		var study_button := _button(actions, "Заняться конспектами · 30 минут", _action_study, 320)
		study_button.position = Vector2(365, 122)
		study_button.disabled = bool(state.get_flag("library_notes_studied"))
	if current_location_id == "house_entrance":
		_button(actions, "Проверить подъезд · 15 минут", _action_inspect_stairwell, 320).position = Vector2(18, 186)
	if current_location_id == "yard_17" or current_location_id == "house_entrance":
		var ice_button := _button(actions, "Убрать лёд у входа · 20 минут", _action_clear_ice, 320)
		ice_button.position = Vector2(365, 186)
		ice_button.disabled = bool(state.get_flag("yard_ice_cleared"))
	var eat_button := _button(screen_root, "Съесть хлеб", _action_eat_bread, 220)
	eat_button.position = Vector2(55, 610)
	eat_button.disabled = not state.has_item("хлеб")
	var meal_button := _button(screen_root, "Съесть обед", _action_eat_meal, 220)
	meal_button.position = Vector2(295, 610)
	meal_button.disabled = not state.has_item("обед")
	_button(screen_root, "Вернуться в район", func(): _show_district(str(state.data.current_district)), 240).position = Vector2(535, 610)
	_button(screen_root, "Карта города", _show_map, 220).position = Vector2(795, 610)
	_button(screen_root, "Задания", _show_quests, 180).position = Vector2(1035, 610)

func _odd_job_for_location(location_id: String) -> Dictionary:
	# Небольшие разовые поручения — художественная игровая система, не описание
	# официального трудоустройства несовершеннолетнего в СССР.
	var jobs := {
		"yard_17": {"title":"Помочь дворнику расчистить дорожку", "description":"Дворник один разгребает слежавшийся снег у арки. Он предлагает немного заработать за помощь.", "time":30, "energy":7, "reward":1, "reputation":2},
		"workers_yard": {"title":"Помочь жильцам перенести уголь", "description":"У подъезда оставили несколько мешков. Сосед просит помочь занести их в сарай.", "time":25, "energy":8, "reward":2, "reputation":1},
		"private_yard": {"title":"Расчистить проход у забора", "description":"Хозяин дома пытается открыть калитку после снегопада и просит расчистить узкий проход.", "time":20, "energy":6, "reward":1, "reputation":1},
		"new_yard": {"title":"Помочь дворнику во дворе", "description":"У входа в новый корпус намело снег. Дворник отдаёт вторую лопату и обещает отблагодарить.", "time":25, "energy":7, "reward":1, "reputation":2},
		"market": {"title":"Помочь торговцу с ящиками", "description":"Торговец просит перенести несколько пустых ящиков под навес, пока не началась новая очередь.", "time":20, "energy":6, "reward":2, "reputation":1},
		"canteen": {"title":"Помочь вернуть подносы", "description":"Работница столовой просит собрать оставленные подносы и освободить несколько столов.", "time":15, "energy":4, "reward":1, "reputation":1}
	}
	return jobs.get(location_id, {})

func _odd_job_flag(location_id: String) -> String:
	return "odd_job_%04d_%02d_%02d_%s" % [int(state.data.year), int(state.data.month), int(state.data.day), location_id]

func _show_odd_job(location_id: String) -> void:
	var job := _odd_job_for_location(location_id)
	if job.is_empty() or bool(state.get_flag(_odd_job_flag(location_id), false)):
		_show_location_menu()
		return
	_clear_screen()
	_label(screen_root, str(job.title).to_upper(), Vector2(55, 35), Vector2(1100, 48), 29)
	var card := _panel(screen_root, Rect2(55, 115, 1120, 220), Color("#20292d"), 10)
	_label(card, str(job.description), Vector2(20, 20), Vector2(1060, 105), 20)
	_label(card, "Время: %d мин. · Силы: −%d · Награда: %d руб." % [int(job.time), int(job.energy), int(job.reward)], Vector2(20, 145), Vector2(1060, 32), 17, Color("#d6b98a"))
	_label(screen_root, "Это необязательное поручение. В каждом месте его можно выполнить один раз за игровой день.", Vector2(60, 360), Vector2(1100, 35), 15, Color("#aeb6b5"))
	var confirm := _button(screen_root, "Взяться за дело", func(): _resolve_odd_job(location_id), 340)
	confirm.position = Vector2(60, 430)
	confirm.disabled = int(state.data.energy) < int(job.energy)
	_button(screen_root, "Отказаться", _show_location_menu, 220).position = Vector2(430, 430)

func _resolve_odd_job(location_id: String) -> void:
	var job := _odd_job_for_location(location_id)
	if job.is_empty() or bool(state.get_flag(_odd_job_flag(location_id), false)) or int(state.data.energy) < int(job.get("energy", 0)):
		_show_location_menu()
		return
	state.advance_time(int(job.time))
	state.change_stat("energy", -int(job.energy))
	state.change_stat("cash", int(job.reward))
	state.change_stat("reputation", int(job.reputation))
	state.set_flag(_odd_job_flag(location_id), true)
	state.add_journal("Алексей помог: %s. Получено %d руб." % [str(job.title).to_lower(), int(job.reward)])
	SaveManager.save_game(state)
	_show_location_menu()

func _show_roam_event(event_id: String) -> void:
	var event: Dictionary = {}
	for location_id in MapData.ROAM_EVENTS:
		var candidate: Dictionary = MapData.ROAM_EVENTS[location_id]
		if str(candidate.get("id", "")) == event_id:
			event = candidate
			break
	if event.is_empty():
		_show_location_menu()
		return
	_clear_screen()
	_label(screen_root, str(event.get("title", "Ситуация")).to_upper(), Vector2(55, 35), Vector2(1050, 48), 30)
	var card := _panel(screen_root, Rect2(55, 115, 1120, 220), Color("#20292d"), 10)
	_label(card, str(event.get("description", "")), Vector2(20, 20), Vector2(1070, 150), 21)
	_label(screen_root, "КАК ПОСТУПИТЬ?", Vector2(60, 365), Vector2(600, 35), 20, Color("#d6b98a"))
	var y := 415.0
	for choice in event.get("choices", []):
		var option: Dictionary = choice
		_button(screen_root, str(option.get("text", "Выбрать")), func(): _resolve_roam_event(event_id, option), 620).position = Vector2(60, y)
		y += 58.0
	_button(screen_root, "Назад", _show_location_menu, 180).position = Vector2(730, 610)

func _roam_event_flag(event_id: String) -> String:
	return "roam_event_%04d_%02d_%02d_%s_done" % [int(state.data.year), int(state.data.month), int(state.data.day), event_id]

func _resolve_roam_event(event_id: String, choice: Dictionary) -> void:
	var flag := _roam_event_flag(event_id)
	if bool(state.get_flag(flag, false)):
		_show_location_menu()
		return
	var minutes := maxi(0, int(choice.get("time", 0)))
	state.advance_time(minutes)
	state.change_stat("energy", int(choice.get("energy", 0)))
	state.change_stat("reputation", int(choice.get("reputation", 0)))
	state.set_flag(flag, true)
	var entry := str(choice.get("journal", "Алексей сделал свой выбор."))
	state.add_journal(entry)
	SaveManager.save_game(state)
	_show_location_menu()

func _location_kind(location_id: String) -> String:
	for district_id in MapData.LOCATIONS:
		for point in MapData.LOCATIONS[district_id]:
			if str(point.get("id", "")) == location_id:
				return str(point.get("kind", "public"))
	return "public"

func _district_travel_minutes(from_id: String, to_id: String) -> int:
	var from_point := Vector2.ZERO
	var to_point := Vector2.ZERO
	for district in MapData.DISTRICTS:
		if str(district.id) == from_id:
			from_point = Vector2(float(district.x), float(district.y))
		if str(district.id) == to_id:
			to_point = Vector2(float(district.x), float(district.y))
	# Travel time is a gameplay estimate based on the schematic map, not a historical timetable.
	return clampi(int(round(from_point.distance_to(to_point) * 55.0)) + 10, 15, 55)

func _action_look_around() -> void:
	state.advance_time(10)
	state.add_journal("Осмотр места: %s. %s" % [current_location_name, current_location_description])
	SaveManager.save_game(state)
	_show_location_menu()

func _action_rest() -> void:
	state.advance_time(30)
	state.change_stat("energy", 18)
	if int(state.data.energy) > 0:
		state.data.exhaustion_minutes = 0
	state.change_stat("health", 2)
	state.add_journal("Алексей немного передохнул в месте: %s." % current_location_name)
	SaveManager.save_game(state)
	_show_location_menu()

func _action_buy_bread() -> void:
	if int(state.data.cash) < 1:
		_show_location_menu()
		return
	state.change_stat("cash", -1)
	state.add_item("хлеб")
	state.advance_time(5)
	state.add_journal("Куплен хлеб. Игровая стоимость покупки — 1 рубль; это условная цена, не историческая справка.")
	SaveManager.save_game(state)
	_show_location_menu()

func _action_buy_meal() -> void:
	if current_location_id != "canteen" or int(state.data.cash) < 2 or state.has_item("обед"):
		_show_location_menu()
		return
	state.change_stat("cash", -2)
	state.add_item("обед")
	state.advance_time(5)
	state.add_journal("Алексей купил горячий обед в столовой. Цена условная, игровая.")
	SaveManager.save_game(state)
	_show_location_menu()

func _action_eat_bread() -> void:
	if not state.has_item("хлеб"):
		_show_location_menu()
		return
	state.remove_item("хлеб")
	state.change_stat("hunger", 35)
	state.change_stat("energy", 8)
	state.change_stat("health", 1)
	state.advance_time(10)
	state.add_journal("Алексей съел хлеб и немного утолил голод.")
	SaveManager.save_game(state)
	_show_location_menu()

func _action_eat_meal() -> void:
	if not state.has_item("обед"):
		_show_location_menu()
		return
	state.remove_item("обед")
	state.change_stat("hunger", 55)
	state.change_stat("energy", 12)
	state.change_stat("health", 2)
	state.advance_time(20)
	state.add_journal("Алексей съел горячий обед. Силы немного восстановились.")
	SaveManager.save_game(state)
	_show_location_menu()

func _action_sleep() -> void:
	if current_location_kind != "home":
		_show_location_menu()
		return
	state.advance_time(480)
	state.change_stat("energy", 100)
	state.data.exhaustion_minutes = 0
	state.change_stat("health", 8)
	state.change_stat("hunger", -18)
	state.add_journal("Алексей лёг спать в квартире и проспал восемь часов. Утром стало легче, но за ночь он проголодался.")
	SaveManager.save_game(state)
	_show_location_menu()

func _action_study() -> void:
	state.advance_time(30)
	state.change_stat("energy", -4)
	state.set_quest("school_notes", "completed")
	state.set_flag("library_notes_studied", true)
	state.add_journal("Алексей провёл время в библиотеке и восстановил часть школьных записей.")
	SaveManager.save_game(state)
	_show_location_menu()

func _action_inspect_stairwell() -> void:
	state.advance_time(15)
	state.set_quest("stairwell_draft", "active")
	state.set_flag("stairwell_window_inspected", true)
	state.add_journal("В подъезде отмечены сквозняк и неисправная подвальная дверь; требуется заявка взрослым.")
	SaveManager.save_game(state)
	_show_location_menu()

func _action_clear_ice() -> void:
	state.advance_time(20)
	state.change_stat("energy", -5)
	state.change_stat("reputation", 1)
	state.set_quest("ice_cleanup", "completed")
	state.set_flag("yard_ice_cleared", true)
	state.add_journal("Алексей помог убрать лёд у входа. Это небольшое дело, но проход стал безопаснее.")
	SaveManager.save_game(state)
	_show_location_menu()

func _district_for_location(location_name: String) -> String:
	for district_id in MapData.LOCATIONS:
		for point in MapData.LOCATIONS[district_id]:
			if point.name == location_name:
				return str(district_id)
	return "teplokontrol"

func _show_journal() -> void:
	_clear_screen()
	_label(screen_root, "ЛИЧНЫЙ ЖУРНАЛ", Vector2(50, 35), Vector2(900, 50), 32)
	var panel := _panel(screen_root, Rect2(50, 115, 1180, 500), Color("#20292d"), 10)
	var entries: Array = state.data.get("journal", [])
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(12, 12)
	scroll.size = Vector2(1130, 455)
	panel.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 12)
	scroll.add_child(list)
	if entries.is_empty():
		_label(list, "Записей пока нет.", Vector2.ZERO, Vector2(1000, 40), 18)
	else:
		for entry in entries:
			var l := Label.new()
			l.text = "[%s] %s" % [entry.get("date", ""), entry.get("text", "")]
			l.custom_minimum_size = Vector2(1060, 55)
			l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			l.add_theme_font_size_override("font_size", 17)
			list.add_child(l)
	_button(screen_root, "Задания", _show_quests, 180).position = Vector2(250, 640)
	_button(screen_root, "Люди и вещи", _show_inventory_codex, 220).position = Vector2(450, 640)
	_button(screen_root, "Назад", _show_map, 180).position = Vector2(50, 640)

func _save_current() -> void:
	_show_save_slots("save")

func _show_settings() -> void:
	_clear_screen()
	_label(screen_root, "НАСТРОЙКИ", Vector2(60, 45), Vector2(900, 55), 34)
	var music := CheckBox.new()
	music.text = "Музыка"
	music.position = Vector2(70, 150)
	music.button_pressed = bool(settings.get("music", true))
	screen_root.add_child(music)
	var sfx := CheckBox.new()
	sfx.text = "Звуковые эффекты"
	sfx.position = Vector2(70, 205)
	sfx.button_pressed = bool(settings.get("sfx", true))
	screen_root.add_child(sfx)
	var ambience := CheckBox.new()
	ambience.text = "Атмосфера локаций и напряжённые фоновые звуки"
	ambience.position = Vector2(70, 260)
	ambience.button_pressed = bool(settings.get("ambience", true))
	screen_root.add_child(ambience)
	_button(screen_root, "Сохранить настройки", func():
		settings.music = music.button_pressed
		settings.sfx = sfx.button_pressed
		settings.ambience = ambience.button_pressed
		SaveManager.save_settings(settings)
		if bool(settings.music):
			_play_main_theme()
		else:
			_stop_main_theme()
		if not bool(settings.ambience) and ambience_player != null:
			ambience_player.stop()
		elif current_scene.size() > 0:
			_set_scene_ambience(current_scene)
		_show_title()
	, 360).position = Vector2(70, 340)
	_button(screen_root, "Назад", _show_title, 180).position = Vector2(70, 420)

func _quit_game() -> void:
	get_tree().quit()


func _show_quests() -> void:
	_clear_screen()
	_label(screen_root, "ЗАДАНИЯ И ОБЯЗАТЕЛЬСТВА", Vector2(40, 24), Vector2(1100, 50), 30)
	_label(screen_root, "История выполненных дел и текущие обещания", Vector2(44, 72), Vector2(1120, 28), 14, Color("#aeb6b5"))
	var panel := _panel(screen_root, Rect2(40, 115, 1200, 500), Color("#20292d"), 10)
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(12, 12)
	scroll.size = Vector2(1170, 470)
	panel.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 10)
	scroll.add_child(list)
	var quest_file := FileAccess.open("res://data/quests.json", FileAccess.READ)
	var quest_data: Variant = JSON.parse_string(quest_file.get_as_text()) if quest_file else null
	var definitions: Array = quest_data.get("quests", []) if quest_data is Dictionary else []
	var active_count := 0
	for definition in definitions:
		if not definition is Dictionary:
			continue
		var quest_id := str(definition.get("id", ""))
		if not state.data.quests.has(quest_id):
			continue
		active_count += 1
		var status := str(state.data.quests.get(quest_id, "locked"))
		var status_labels := {"locked":"Не начато", "active":"В процессе", "started":"В процессе", "completed":"Выполнено", "failed":"Провалено", "abandoned":"Оставлено"}
		var status_text := str(status_labels.get(status, status))
		var c := _panel(list, Rect2(0, 0, 1120, 105), Color("#293338"), 8)
		_label(c, str(definition.get("title", quest_id)), Vector2(12, 7), Vector2(850, 28), 17, Color("#d6b98a"))
		_label(c, str(definition.get("description", "")), Vector2(12, 38), Vector2(850, 38), 13, Color("#c3c9c7"))
		_label(c, status_text.to_upper(), Vector2(890, 10), Vector2(200, 28), 13, Color("#d58c72"))
	if active_count == 0:
		_label(list, "Пока нет активных обязательств. Разговаривай с людьми и обращай внимание на просьбы.", Vector2.ZERO, Vector2(1060, 70), 18)
	_button(screen_root, "Назад к карте", _show_map, 220).position = Vector2(40, 635)
	_button(screen_root, "Журнал", _show_journal, 180).position = Vector2(280, 635)

func _show_inventory_codex() -> void:
	_clear_screen()
	_label(screen_root, "ЛЮДИ И ЛИЧНЫЕ ВЕЩИ", Vector2(40, 24), Vector2(1100, 50), 30)
	_label(screen_root, "Знакомые, встреченные люди и то, что Алексей носит с собой", Vector2(44, 72), Vector2(1120, 28), 14, Color("#aeb6b5"))
	var left := _panel(screen_root, Rect2(40, 115, 690, 500), Color("#20292d"), 10)
	_label(left, "ЛЮДИ", Vector2(14, 10), Vector2(600, 30), 19, Color("#d6b98a"))
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(12, 48)
	scroll.size = Vector2(660, 435)
	left.add_child(scroll)
	var people_list := VBoxContainer.new()
	people_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	people_list.add_theme_constant_override("separation", 8)
	scroll.add_child(people_list)
	var character_file := FileAccess.open("res://data/characters.json", FileAccess.READ)
	var character_data: Variant = JSON.parse_string(character_file.get_as_text()) if character_file else null
	var characters: Array = character_data.get("characters", []) if character_data is Dictionary else []
	var relation_names := {"marat":"marat", "senya":"senya", "galya":"galya"}
	for person in characters:
		if not person is Dictionary:
			continue
		var person_name := str(person.get("name", "Без имени"))
		var person_id := str(person.get("id", ""))
		var age_text := " · %d лет" % int(person.get("age", 0)) if int(person.get("age", 0)) > 0 else ""
		var relation_text := ""
		if relation_names.has(person_id):
			relation_text = " · отношение: %d" % int(state.data.relationships.get(person_id, 0))
		var card := _panel(people_list, Rect2(0, 0, 620, 112), Color("#293338"), 8)
		var portrait_path := str(person.get("portrait", ""))
		if not portrait_path.is_empty() and ResourceLoader.exists(portrait_path):
			var portrait := TextureRect.new()
			portrait.texture = load(portrait_path) as Texture2D
			portrait.position = Vector2(8, 8)
			portrait.size = Vector2(76, 94)
			portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
			card.add_child(portrait)
		var text_x := 96.0 if not portrait_path.is_empty() else 12.0
		_label(card, person_name + age_text, Vector2(text_x, 7), Vector2(510, 27), 17, Color("#d6b98a"))
		_label(card, str(person.get("role", "")) + relation_text, Vector2(text_x, 35), Vector2(510, 22), 13, Color("#c3c9c7"))
		_label(card, str(person.get("description", "")), Vector2(text_x, 59), Vector2(510, 45), 12, Color("#aeb6b5"))
	var right := _panel(screen_root, Rect2(750, 115, 490, 500), Color("#20292d"), 10)
	_label(right, "СОСТОЯНИЕ АЛЕКСЕЯ", Vector2(16, 12), Vector2(440, 32), 19, Color("#d6b98a"))
	_label(right, "Наличные: %d руб." % int(state.data.cash), Vector2(16, 60), Vector2(440, 28), 17)
	_label(right, "Здоровье: %d / 100" % int(state.data.health), Vector2(16, 94), Vector2(440, 28), 16)
	_label(right, "Силы: %d / 100" % int(state.data.get("energy", 100)), Vector2(16, 126), Vector2(440, 28), 16)
	_label(right, "Сытость: %d / 100" % int(state.data.get("hunger", 100)), Vector2(16, 158), Vector2(440, 28), 16)
	_label(right, "Репутация: %d" % int(state.data.reputation), Vector2(16, 190), Vector2(440, 28), 16)
	_label(right, "ЛИЧНЫЕ ВЕЩИ", Vector2(16, 235), Vector2(440, 30), 19, Color("#d6b98a"))
	var items: Array = state.data.get("inventory", [])
	var inventory_text := "Пока карманы почти пусты." if items.is_empty() else "\n".join(items)
	_label(right, inventory_text, Vector2(16, 277), Vector2(440, 165), 16, Color("#b9c0bf"))
	_button(screen_root, "Назад к карте", _show_map, 220).position = Vector2(40, 635)
	_button(screen_root, "Журнал", _show_journal, 180).position = Vector2(280, 635)


func _show_transport() -> void:
	_clear_screen()
	_label(screen_root, "ГОРОДСКОЙ ТРАНСПОРТ · 1981", Vector2(50, 28), Vector2(1100, 50), 32)
	_label(screen_root, "Выбери район назначения. Время поездки — условная игровая оценка; точные трассы остановок не заявляются.", Vector2(54, 82), Vector2(1160, 34), 14, Color("#aeb6b5"))
	var panel := _panel(screen_root, Rect2(50, 135, 1180, 465), Color("#20292d"), 10)
	_label(panel, "ТЕКУЩИЙ РАЙОН: %s" % _district_name(str(state.data.current_district)).to_upper(), Vector2(18, 12), Vector2(1100, 32), 19, Color("#d6b98a"))
	_label(panel, "Перед поездкой проверь время и силы. Поездка расходует игровое время, но не деньги: историческая цена проезда пока не подтверждена.", Vector2(18, 50), Vector2(1100, 50), 14, Color("#c3c9c7"))
	var y := 112.0
	for district in MapData.DISTRICTS:
		var destination := str(district.id)
		if destination == str(state.data.current_district):
			continue
		var travel_minutes := maxi(8, int(round(_district_travel_minutes(str(state.data.current_district), destination) * 0.55)))
		var route_button := _button(panel, "До %s · около %d мин." % [str(district.name), travel_minutes], func(): _travel_by_transit(destination, travel_minutes), 600)
		route_button.position = Vector2(18, y)
		y += 62.0
	_button(screen_root, "Назад к карте", _show_map, 220).position = Vector2(50, 635)

func _district_name(district_id: String) -> String:
	for district in MapData.DISTRICTS:
		if str(district.id) == district_id:
			return str(district.name)
	return district_id.capitalize()

func _travel_by_transit(destination: String, minutes: int) -> void:
	if destination == str(state.data.current_district):
		_show_map()
		return
	var origin := str(state.data.current_district)
	state.advance_time(minutes)
	state.data.current_district = destination
	state.add_journal("Алексей добрался на городском транспорте из района «%s» в район «%s» примерно за %d минут. Маршрут — игровая условность." % [_district_name(origin), _district_name(destination), minutes])
	_play_sfx("footstep_snow")
	SaveManager.save_game(state)
	_show_district(destination)

