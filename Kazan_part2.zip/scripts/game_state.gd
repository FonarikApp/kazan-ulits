extends RefCounted
class_name GameState

const DEFAULTS := {
	"save_version": 4,
	"hero_name": "Алексей",
	"hero_surname": "Кузнецов",
	"hero_age": 15,
	"hero_nickname": "",
	"hero_group_joined": false,
	"hero_nickname_unlocked": false,
	"origin": "Теплоконтроль",
	"chapter": 1,
	"scene_id": "intro_yard",
	"line_index": 0,
	"day": 26,
	"month": 11,
	"year": 1981,
	"hour": 16,
	"minute": 20,
	"cash": 12,
	"health": 100,
	"energy": 100,
	"hunger": 100,
	"fatigue_minutes": 0,
	"hunger_minutes": 0,
	"starvation_minutes": 0,
	"exhaustion_minutes": 0,
	"reputation": 0,
	"flags": {},
	"relationships": {"marat": 0, "senya": 0, "galya": 0, "district": 0},
	"visited": [],
	"journal": [],
	"inventory": [],
	"quests": {},
	"current_district": "teplokontrol",
	"play_minutes": 0,
	"ending": "",
	"chapter_history": [],
	"last_save_slot": 1
}

var data: Dictionary = {}

func _init() -> void:
	reset()

func reset() -> void:
	data = DEFAULTS.duplicate(true)

func hero_display_name() -> String:
	var base := "%s %s" % [str(data.get("hero_name", "Алексей")), str(data.get("hero_surname", "Кузнецов"))]
	if bool(data.get("hero_nickname_unlocked", false)) and bool(data.get("hero_group_joined", false)):
		return "%s «%s»" % [base, str(data.get("hero_nickname", "Кузнец"))]
	return base

func set_group_membership(joined: bool) -> void:
	data["hero_group_joined"] = joined
	if not joined:
		data["hero_nickname_unlocked"] = false

func unlock_hero_nickname(nickname: String = "Кузнец") -> void:
	if bool(data.get("hero_group_joined", false)):
		data["hero_nickname"] = nickname
		data["hero_nickname_unlocked"] = true

func get_flag(key: String, fallback: Variant = false) -> Variant:
	return data.get("flags", {}).get(key, fallback)

func set_flag(key: String, value: Variant) -> void:
	data["flags"][key] = value

func change_relation(character: String, amount: int) -> void:
	var relations: Dictionary = data["relationships"]
	relations[character] = clampi(int(relations.get(character, 0)) + amount, -100, 100)

func change_stat(stat_name: String, amount: int) -> void:
	if not data.has(stat_name):
		return
	match stat_name:
		"health": data[stat_name] = clampi(int(data[stat_name]) + amount, 0, 100)
		"energy", "hunger": data[stat_name] = clampi(int(data[stat_name]) + amount, 0, 100)
		"cash": data[stat_name] = maxi(0, int(data[stat_name]) + amount)
		"reputation": data[stat_name] = clampi(int(data[stat_name]) + amount, -100, 100)

func set_quest(quest_id: String, status: String) -> void:
	data["quests"][quest_id] = status

func add_item(item_id: String) -> void:
	var inventory: Array = data["inventory"]
	if not inventory.has(item_id):
		inventory.append(item_id)

func advance_time(minutes: int) -> void:
	if minutes <= 0:
		return
	var total := int(data["hour"]) * 60 + int(data["minute"]) + minutes
	var days_passed := int(total / 1440)
	data["hour"] = int((total % 1440) / 60)
	data["minute"] = total % 60
	data["play_minutes"] = int(data.get("play_minutes", 0)) + minutes
	# Потребности обновляются накопительно: короткие действия не теряют остаток времени.
	var accumulated_fatigue := int(data.get("fatigue_minutes", 0)) + minutes
	var fatigue_units := int(accumulated_fatigue / 45)
	data["fatigue_minutes"] = accumulated_fatigue % 45
	if fatigue_units > 0:
		data["energy"] = clampi(int(data.get("energy", 100)) - fatigue_units, 0, 100)
	var accumulated_hunger := int(data.get("hunger_minutes", 0)) + minutes
	var hunger_units := int(accumulated_hunger / 120)
	data["hunger_minutes"] = accumulated_hunger % 120
	if hunger_units > 0:
		data["hunger"] = clampi(int(data.get("hunger", 100)) - hunger_units, 0, 100)
	if int(data.get("hunger", 100)) <= 0:
		var accumulated_starvation := int(data.get("starvation_minutes", 0)) + minutes
		var health_loss := int(accumulated_starvation / 90)
		data["starvation_minutes"] = accumulated_starvation % 90
		if health_loss > 0:
			data["health"] = clampi(int(data.get("health", 100)) - health_loss, 0, 100)
	else:
		data["starvation_minutes"] = 0
	# Полное истощение опасно: если герой продолжает действовать без сил,
	# здоровье постепенно снижается. Сон и отдых снимают накопленный перегруз.
	if int(data.get("energy", 100)) <= 0:
		var accumulated_exhaustion := int(data.get("exhaustion_minutes", 0)) + minutes
		var exhaustion_loss := int(accumulated_exhaustion / 180)
		data["exhaustion_minutes"] = accumulated_exhaustion % 180
		if exhaustion_loss > 0:
			data["health"] = clampi(int(data.get("health", 100)) - exhaustion_loss, 0, 100)
	else:
		data["exhaustion_minutes"] = 0
	for _day in range(days_passed):
		advance_day()

func advance_day() -> void:
	var date := int(data["day"]) + 1
	var month := int(data["month"])
	var year := int(data["year"])
	var days_in_month := [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
	if date > days_in_month[month - 1]:
		date = 1
		month += 1
		if month > 12:
			month = 1
			year += 1
	data["day"] = date
	data["month"] = month
	data["year"] = year
	data["journal"].append({"date": _date_string(), "text": "Наступил новый день."})

func remove_item(item_id: String) -> void:
	var inventory: Array = data["inventory"]
	inventory.erase(item_id)

func has_item(item_id: String) -> bool:
	return data["inventory"].has(item_id)

func add_journal(entry: String) -> void:
	var journal: Array = data["journal"]
	journal.append({"date": _date_string(), "text": entry})

func _date_string() -> String:
	return "%02d.%02d.%04d" % [data["day"], data["month"], data["year"]]

func mark_visited(location_id: String) -> void:
	var visited: Array = data["visited"]
	if not visited.has(location_id):
		visited.append(location_id)
